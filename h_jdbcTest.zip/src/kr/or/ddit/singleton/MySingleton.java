package kr.or.ddit.singleton;

/*
 	- singleton 패턴 : 객체가 1개만 만들어지게 하는 방법
 					 (외부에서 new 명령을 사용하지  못하게 한다.)
 		
 					 
 	- singleton 클래스를 만드는 방법(필수 구성 요소 )
 		1. 자신 Class의 참조값이 저장될 변수를 private static으로 선언한다. 
 		
 		2. 생성자의 접근 제한자를 private으로 한다.
 		
 		3. 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
 				( 이 메서드의 이름은 보통 getInstance()로 한다. )

 
 */
public class MySingleton {

//	외부에서 접근을 하지 못하게 private 사용 
	
		//1번
	private static MySingleton single;
	
		//2번
	private MySingleton() {
		System.out.println("생성자 입니다.");
	}
	
		//3번 static메서드 안에서는 static변수만 사용 가능 
	public static MySingleton getInstance() {
		
		if(single==null) single = new MySingleton();
		
		return single;
	}
	
	// 기타 이 클래스가 처리할 내용을 작성한다.
	public void displayTest() {
		System.out.println("이것은 싱글톤 클래스의 메서드 처리 내용입니다.");
	
	}
	
	//처음에는 null값이라 객체가 생성되고, 두번째 실행할 때는 값이 들어가 있으므로 객체는 하나만 실행된다
	//싱글톤패턴 사용 : 어떤 클래스를 만들었는데 클래스안에 주로 메서드만 있는 경우 (메서드 호출만 하면됨), 
	//				데이터가 항상 한개만 유지되어야 할때 : 데이터베이스의 역할을 하는 클래스 
	// ==> 거의 메서드로만 구성된 클래스, 데이터가 항상 한개만 유지하여 그곳에만 변화 할 때 주로 사용 
	
	
}
