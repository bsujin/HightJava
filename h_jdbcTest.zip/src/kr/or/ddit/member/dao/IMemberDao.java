package kr.or.ddit.member.dao;

import java.util.List;

import kr.or.ddit.member.vo.MemberVo;

/**
 * 실제 DB와 연결해서 SQL문을 수행하여 결과를 작성해서 Service에 전달하는 DAO의 interface
 *	db와 연결하여 어떤 작업을 하는지 파악 하여 작성하기 
 *
 * 인터페이스를 먼저 만드는 이유 : 인터페이스는 틀 - 어떠한 변수에도 다양하게 사용, 유지보수를 편하게 하기 위함  ==> 다용성
 * 각 db마다 사용하는 매서드가 달라서 db가 변경되었을 때, 안에있는 내용을 바꾸려면 클래스를 새로 만들어야 하므로 기본 틀만 만드는 인터페이스를 구현함 
 * 
 */

public interface IMemberDao {
	
	// 실제 db와 연결해서 어떤 작업을 할지, 작업에 필요한 데이터가 무엇인지, 데이터의 결과를 어떻게 보낼지 생각하기
	
	/**
	 * MemberVO에 담겨진 자료를 DB에 insert하는 메서드
	 * 
	 * @param memVo 	DB에 insert할 자료가 저장된 MemberVO객체
	 * @return			insert작업 성공 : 1, 실패 : 0
	 * 
	 */

	//insert 작업 -> insert할 데이터는 controller에서 만들기 
	public int  insertMember(MemberVo memVo);
	
	
	/**
	 * 회원ID를 매개값으로 받아서 해당 회원 정보를 삭제하는 메서드
	 * 
	 * @param memId		삭제할 회원Id
	 * @return			삭제성공 : 1, 삭제 실패 : 0 
	 * 
	 */
	
	// 삭제 작업 : 회원 아이디로 삭제 
	public int deleteMember(String memId);
	
	
	
	/**
	 * MemberVO에 담겨진 정보를 이용하여 회원 정보를 수정하는 메서드
	 * 
	 * @param memVo			수정할 정보가 저장된 MemVO객체
	 * @return				수정성공 : 1, 수정 실패 0 ; 
	 * 
	 */
	
 	//수정작업 : id를 제외한 나머지 정보  
	public int updateMember(MemberVo memVo);
	
	/**
	 * DB의 회원 테이블의 전체 레코드를 가져와서 List에 담아서 반환하는 메서드 
	 * @return		MemberVo의 객체를 담고있는 List객체 
	 */
	
	//전체 자료 출력  : dao에서 select로 가져온 데이터를 collection(list)에 담아서 보낸다.
	public List<MemberVo> getAllMemberList();
	
	/**
	 * 회원id를 매개값으로 받아서 해당 회원의 개수를 반환하는 메서드 
	 * 
	 * @param memId		검색할 회원ID
	 * @return			검색 된 회원ID 개수 
	 */
	public int getMemberCount(String memId);
	
	
	/**
	 * update2메뉴 선택하여 각 부메뉴에 해당하는 데이터를 수정하기 
	 * @param memVo
	 * @return
	 * 
	 */
	//자료수정 2 메뉴	 1. 회원이름수정
	public int updateMemName(MemberVo memVo);
	
	//2. 회원 전화번호 수정 
	public int updateMemTel(MemberVo memVo);
	
	//3. 회원주소수정
	public int updateMemaddr(MemberVo memVo);
	

}
