package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoImpl;
import kr.or.ddit.member.vo.MemberVo;

//서비스는 DAO쪽을 부른다. 그러므로 DAO객체를 생성해야한다.

public class MemberServiceImpl implements IMemberService {
	
	private IMemberDao dao;	//DAO객체가 저장될 변수 선언 
	
	//생성자
	public MemberServiceImpl() {
		dao = new MemberDaoImpl();		
		//dao가 싱글톤일 경우 new를 사용하였으므로 에러가 난다 
		// dao = MemberDao_SingleTone.getInstance();	
	}
	
	
	@Override
	public int insertMember(MemberVo memVo) {
		return dao.insertMember(memVo);
	}

	@Override
	public int deleteMember(String memId) {
		return dao.deleteMember(memId);
	}

	@Override
	public int updateMember(MemberVo memVo) {
		return dao.updateMember(memVo);
	}

	@Override
	public List<MemberVo> getAllMemberList() {
		return dao.getAllMemberList();
	}

	@Override
	public int getMemberCount(String memId) {
		return dao.getMemberCount(memId);
	}
	
	@Override
	public int updateMemName(MemberVo memVo) {
		return dao.updateMemName(memVo);
	}

	@Override
	public int updateMemTel(MemberVo memVo) {
		return dao.updateMemTel(memVo);
	}

	@Override
	public int updateMemaddr(MemberVo memVo) {
		return dao.updateMemaddr(memVo);
	}

}
