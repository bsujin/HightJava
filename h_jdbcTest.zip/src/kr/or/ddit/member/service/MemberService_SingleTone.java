package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDao_SingleTone;
import kr.or.ddit.member.vo.MemberVo;

public class MemberService_SingleTone implements IMemberService{

	private IMemberDao dao;
	
	//1번 자신 class의 참조값이 저장될 변수를 private static으로 선언한다.
	private static MemberService_SingleTone service;
	
	//2번 생성자의 접근 제한자를 private로 한다.
	private MemberService_SingleTone() {	
		dao = MemberDao_SingleTone.getInstance();
	}
   
   //3번 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
	public static MemberService_SingleTone getInstance() {
		if(service==null) service = new MemberService_SingleTone();
		return service;
		
	}

	@Override
	public int insertMember(MemberVo memVo) {
		return dao.insertMember(memVo);
	}

	@Override
	public int deleteMember(String memId) {
		return dao.deleteMember(memId);
	}

	@Override
	public int updateMember(MemberVo memVo) {
		return dao.updateMember(memVo);
	}

	@Override
	public List<MemberVo> getAllMemberList() {
		return dao.getAllMemberList();
	}

	@Override
	public int getMemberCount(String memId) {
		return dao.getMemberCount(memId);
	}

	@Override
	public int updateMemName(MemberVo memVo) {
		
		return dao.updateMemName(memVo);
	}

	@Override
	public int updateMemTel(MemberVo memVo) {
		
		return dao.updateMemTel(memVo);
	}

	@Override
	public int updateMemaddr(MemberVo memVo) {
		// TODO Auto-generated method stub
		return dao.updateMemaddr(memVo);
	}

	

}
