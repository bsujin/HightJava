package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcTest05_merge {

	public static void main(String[] args) {
		//merge를 사용할 경우에는 update가 되버리므로 문제와 다른 상황,,,
		
		Scanner scan = new Scanner(System.in);
		
		Connection conn = null;
		PreparedStatement pst = null;
		
		try {
			
			Class.forName("Oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:Oracle:thin:@localhost:1521:xe");
			
			System.out.println("추가할 Lprod_gu값을 입력 > ");
			String gu = scan.nextLine();
		
			System.out.println("추가할 Lprid_nm값을 입력 > ");
			String nm = scan.nextLine();
			
		 String sql = "MERGE INTO LPROD " +
				 	"USING DUAL ON ( LPROD_GU = ? ) "
				 + "WHEN MATCHED THEN " +
				 " Update prod set( (SELECT MAX(LPROD_ID)+1 FROM LPROD) , ? , ?)"
				 + "WHEN NOT MATCHED THEN " +
				 " Insert into lprod values( (SELECT MAX(LPROD_ID)+1 FROM LPROD) , ? , ?)";
		//
		}catch (SQLException e) {
			// TODO: handle exception
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
