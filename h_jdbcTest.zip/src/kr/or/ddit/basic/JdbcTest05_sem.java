package kr.or.ddit.basic;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import kr.or.ddit.dbUtill.DButil;

public class JdbcTest05_sem {

	public static void main(String[] args) {
		// select문을 각자 따로 실행하는 방법을 사용
		
		
Scanner scan = new Scanner(System.in);
		
		Connection conn = null;
		PreparedStatement pst = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
//			
//			Class.forName("Oracle.jdbc.driver.OracleDriver");
//			conn = DriverManager.getConnection("jdbc:Oracle:thin:@localhost:1521:xe");
//			
			conn = DButil.getConnection();
			
			String sql1 = "select nvl(max(lprod_id),0) maxnum from lprod";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql1);
			int maxNum = 0;
			if(rs.next()) {
			 maxNum = rs.getInt("maxnum"); 		
 
			}
		maxNum++;
		
		//입력받은 lprod_gu가 이미 등록된 데이터이면 다시 입력받아서 처리한다.
		int count = 0;
		String gu;
		do {
	
			System.out.println("상품 분류 코드 입력 : " );
			gu = scan.next();
			
			String sql2 = "SELECT COUNT(*) cnt FROM lprod WHERE lprod_gu = ?";
			pst = conn.prepareStatement(sql2);
			pst.setString(1, gu);
			
			rs = pst.executeQuery();		
			//select문에서만 사용 : 데이터의 정보를 담아준다.
			
			//rs.next는 값이 있으면 true 없으면 false를 반환한다.
			if(rs.next()) {
				count = rs.getInt("cnt");
			}
			if(count>0) {
				System.out.println("입력한 상품 분류 코드" + gu);
			}
			}while(count>0);

			System.out.println("상품 분류명 입력 : " );
			String nm = scan.next();
			
			String sql3 = "Insert into lprod (lprod_id, lprod_gu, lprod_nm)"
					+" values (?,?,?)";
			pst = conn.prepareStatement(sql3);
			pst.setInt(1, maxNum);
			pst.setString(2, gu);
			pst.setString(3, nm);
			
			int cnt = pst.executeUpdate();
			
			if(cnt>0) {
				System.out.println("DB 추가 성공 !!!");
			}else {
				System.out.println("DB 추가 실패 ~~");
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
//		}
//		catch (ClassNotFoundException e) {
//			e.printStackTrace();
		}finally{
//			resultset을 제일 먼저, conn을 나중에 닫아야 한다
			if (rs!=null) try { rs.close(); } catch (Exception e) {  }
			if (stmt!=null) try { stmt.close(); } catch (Exception e) {	}
			if (pst!=null) try { pst.close(); } catch (Exception e) {	}
			if (conn!=null) try { conn.close(); } catch (Exception e) {	}
		}
		}
	}
