package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import kr.or.ddit.dbUtill.DButil3;

public class JdbcBoard_t {


	Connection conn = null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		//게시판 테이블 구조 및 시퀀스 
		
		new JdbcBoard_t().start();

	}
	
	private void start() {

		while (true) {
			int number = view();
			switch (number) {
			case 1:
				write();
				break;
			
			case 2 : 
				boardList();
				break;

			default:
				System.out.println("잘못입력했습니다. 다시 입력해주세요.");
				break;
			}
		}
	}
		
	//게시글을 보는 메서드 
	private void boardList() {
		System.out.println();
		System.out.print("보기를 원하는 게시물 번호 입력 >>");
		int no = scan.nextInt();
		
		try {
			conn = DButil3.getConnection();
			String sql = "Select * from jdbc_board WHERE = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, no);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				System.out.println(" 제목 : " + rs.getString("board_title")
				+"\n 작성자 : " + rs.getString("board_writer")
				+ " \n 내용 : " + rs.getString("board_content")
				+ " \n 작성일 : " + rs.getDate("board_date")
				+ " \n 조회수 : " +  rs.getInt("board_cnt"));
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		switch (no) {
		case 1:
			update(no);
			break;
		case 2 :
			delete(no);
			break;
		case 3 :
			return;	//반복문을 받고있으므로 이전으로 가기 
		default:
			System.out.println("잘못입력했습니다. 다시 입력해주세요.");
			break;
		}
		
	}
// 삭제하는 메서드
	private void delete(int no) {
		// TODO Auto-generated method stub
		
	}

// 수정하는 메서드 
	private void update(int no) {
		// TODO Auto-generated method stub
		
	}

	//게시판에 글을 작성하는 메서드 
		private void write() {
			
			System.out.println("게시판에  작성할 글을 입력해주세요");
			System.out.print(" 제목 >>");
			String title = scan.nextLine();
			
			System.out.print(" 작성자 >>");
			String user = scan.nextLine();
			
			System.out.println(" 내용>>");
			String content = scan.nextLine();
			
			try {
				
				conn = DButil3.getConnection();
				
				//		Insert into jdbc_board (board_no, board_title, board_writer, board_date, board_cnt, board_content)
				// 		values (3, '제목', '나나', sysdate, 0, 'fff');
				
				
				String sql = " Insert into jdbc_board values (board_seq.nextVal , ? , ? ,sysdate, 0, ?)";
				
				ps = conn.prepareStatement(sql);
				ps.setString(1, title);
				ps.setString(2, user);
				ps.setString(3, content);
				
				int succes = ps.executeUpdate();
				if(succes>0) {
					System.out.println(succes + " 개 글이 추가되었습니다.");
					System.out.println("추가 작업 성공~~~");
					System.out.println();
				}else {
					System.out.println("수정 작업 실패!!!");
					System.out.println();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
		
			
			
			
	}

		//리턴값과 반환값이 있는 메서드 
	public int view() {

		while (true) {
			System.out.println("-----------------------------");
			System.out.println(" NO      제목           작성자     조회수");
			System.out.println("-----------------------------");

			try {

				conn = DButil3.getConnection();

				String sql = "SELECT * FROM jdbc_board ORDER BY  board_no DESC";

				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getString("board_no") +"\t"+ rs.getString("board_title")+"\t"
							+ rs.getString("board_writer") +"\t"+ rs.getInt("board_cnt"));
				}
				System.out.println("--------------------------------");
				System.out.println(" 메뉴 : 1. 새글작성       2. 게시글 보기      3.검색       0. 작업끝");
				System.out.print(" 작업 선택 >> ");

				int input = Integer.parseInt(scan.nextLine());
				return input;

			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				if(rs!=null) try { rs.close(); } catch (Exception e) { }
				if(ps!=null) try { ps.close(); } catch (Exception e) { }
				if(conn!=null) try { conn.close(); } catch (Exception e) { }
		}
		
		

		
		}//while문 끝
		
	}	//view 메서드 끝


		
	
	
	

}
