package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import kr.or.ddit.dbUtill.DButil;

public class JdbcBoard {


	Connection conn = null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	Statement st = null;
	Scanner scan = new Scanner(System.in);
	
	int boardNo = 0;
	int menu = 0;
	String title = null;
	String content = null;
	String user = null;
	
	public static void main(String[] args) {
		//게시판 테이블 구조 및 시퀀스 
		
		new JdbcBoard().start();

	}
	
	private void start() {
		
		while (true) {
	
			if (menu == 0) {
				view();
			}

			System.out.println(" 메뉴 : 1. 새글작성       2. 게시글 보기      3.검색       0. 작업끝");
			System.out.print(" 작업 선택 >> ");


			int input = Integer.parseInt(scan.nextLine());
			
		
		
			switch (input) {
			case 1:
				write();
				break;
			
			case 2 : 
				boardList();
				break;

			case 3 : 
				search();
				break;

			default:
				System.out.println("잘못입력했습니다. 다시 입력해주세요.");
				break;
			}
		}
	}
		
	//게시글을 검색하는 메서드 
	private void search() {

		try {
			conn=DButil.getConnection();
			
			System.out.print("검색할 제목 입력 >>");
			title = scan.nextLine();
			
			//	SELECT * FROM jdbc_board WHERE BOARD_TITLE like '%S%';
			String sql = "SELECT * FROM jdbc_board WHERE board_title Like '%" + title + "%' "; 
			
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			
			if(title.equals("")) {
				return;
			}else if (rs.next()) {
				System.out.println("----------------------------------------");
				System.out.println("  NO \t 제목   \t   작성자  \t 조회수");
				System.out.println("----------------------------------------");
				System.out.println("  " +rs.getString("board_no") +"\t"
							+ rs.getString("board_title")+"\t  "
						+ rs.getString("board_writer") +"\t "
							+ rs.getInt("board_cnt"));
				System.out.println("----------------------------------------");
				menu = 1;
			}else {
					System.out.println();
					System.out.println(" 검색어와 맞는 게시글이 없습니다.");
					System.out.println();
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(rs!=null) try { rs.close();	} catch (Exception e) { }
			if(ps!=null) try { ps.close();	} catch (Exception e) { }
			if(conn!=null) try { conn.close();	} catch (Exception e) { }
		}
		
	}

	//게시글을 보는 메서드 
	private void boardList() {
		
		try {
		System.out.println();
		System.out.print("보기를 원하는 게시물 번호 입력 >>");
		boardNo = Integer.parseInt(scan.nextLine());
		}catch (Exception e) {
			System.out.println("번호를 다시 입력해주세요.");
			return;
		}
		try {
			conn = DButil.getConnection();
			String sql = "Select count(*) cnt from jdbc_board WHERE board_no = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();
			
			if (rs.next()) {

				if (rs.getInt("cnt") == 0) {
					System.out.println("없는 게시물입니다.");
					System.out.println();
					return;
				}
			}
				
				//조회수가 증가되는 SQL문 
//				UPDATE JDBC_BOARD SET BOARD_CNT = BOARD_CNT+1  WHERE BOARD_NO = 1;
				String sql1 = " UPDATE JDBC_BOARD SET BOARD_CNT = BOARD_CNT+1 WHERE board_no = ?"; 
				ps = conn.prepareStatement(sql1);
				ps.setInt(1, boardNo);
				ps.executeUpdate();
			
				//조회하는 sql문 
				String sqlView= "SELECT * FROM jdbc_board WHERE board_no = ?";
				ps = conn.prepareStatement(sqlView); 
				ps.setInt(1, boardNo);
				rs = ps.executeQuery();

			System.out.println("-----------------------------------------");
			while (rs.next()) {
				System.out.println(" 제목 : " + rs.getString("board_title") 
						+ "\n 작성자 : " + rs.getString("board_writer")
						+ " \n 내용 : " + rs.getString("board_content") 
						+ " \n 작성일 : " + rs.getDate("board_date")
						+ " \n 조회수 : " + rs.getInt("board_cnt"));
			}
			System.out.println("-----------------------------------------");

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(rs!=null) try { rs.close();	} catch (Exception e) { }
			if(ps!=null) try { ps.close();	} catch (Exception e) { }
			if(conn!=null) try { conn.close();	} catch (Exception e) { }
		}
		
		int input = 0;
		try {
		System.out.println("메뉴 : 1.수정      2.삭제     3.리스트로 가기  ");
		System.out.println("메뉴를 입력하세요>>");
		input = Integer.parseInt(scan.nextLine());
		}catch (Exception e) {
			System.out.println("메뉴에 맞는 숫자를  입력해주세요.");
		}
		switch (input) {
		case 1:
			update(boardNo);
			break;
		case 2 :
			delete(boardNo);
			break;
		case 3 :
			return;	//반복문을 받고있으므로 이전으로 가기 
//		default:
//			System.out.println("잘못입력했습니다. 다시 입력해주세요.");
//			break;
		}
		
	}
// 삭제하는 메서드
	private void delete(int no) {
		try {
			conn = DButil.getConnection();
			
			String sql = "DELETE jdbc_board WHERE board_no = ?";
			ps= conn.prepareStatement(sql);
			ps.setInt(1, no);
			
			int cnt = ps.executeUpdate();
			System.out.println();
			if(cnt>0) {
				
				System.out.println(no + " 번 글이 삭제 되었습니다.");
			}else {
				System.out.println("게시글 삭제에 실패했습니다.");
			}
			System.out.println();
			
		} catch (Exception e) {
			System.out.println("작업 실패 !! 공백없이 입력해주세요.");
//			e.printStackTrace();
		}finally {
			if(rs!=null) try { rs.close();	} catch (Exception e) { }
			if(ps!=null) try { ps.close();	} catch (Exception e) { }
			if(conn!=null) try { conn.close();	} catch (Exception e) { }
		}
		
		
	}

// 수정하는 메서드 
	private void update(int no) {
		
		try {
			conn = DButil.getConnection();

			System.out.println("수정할 제목을 입력해주세요 >> ");
			title = scan.nextLine();
			System.out.println("수정할 내용을 입력해주세요 >> ");
			content = scan.nextLine();

			String sql = "UPDATE jdbc_board SET board_title = ?, board_content = ? WHERE board_no =?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, title);
			ps.setString(2, content);
			ps.setInt(3, no);

			int cnt = ps.executeUpdate();
			if (cnt > 0) {

				System.out.println(no +"번 글이 수정 되었습니다.");
			} else {
				System.out.println("게시글 수정에 실패했습니다.");
			}
			System.out.println();
						
		} catch (Exception e) {
			System.out.println("작업 실패 !! 공백없이 입력해주세요.");
//			e.printStackTrace();
		}finally {
		if(rs!=null) try { rs.close();	} catch (Exception e) { }
		if(ps!=null) try { ps.close();	} catch (Exception e) { }
		if(conn!=null) try { conn.close();	} catch (Exception e) { }
		}
	}

	//게시판에 글을 작성하는 메서드 
		private void write() {
			
			System.out.println("게시판에  작성할 글을 입력해주세요");
			System.out.print(" 제목 >>");
			title = scan.nextLine();
			
			System.out.print(" 작성자 >>");
			user = scan.nextLine();
			
			System.out.println(" 내용>>");
			content = scan.nextLine();
			
				
			try {
				conn = DButil.getConnection();
				
				//		Insert into jdbc_board (board_no, board_title, board_writer, board_date, board_cnt, board_content)
				// 		values (3, '제목', '나나', sysdate, 0, 'fff');
				
				
				String sql = " Insert into jdbc_board values (board_seq.nextVal , ? , ? ,sysdate, 0, ?)";
				
				ps = conn.prepareStatement(sql);
				ps.setString(1, title);
				ps.setString(2, user);
				ps.setString(3, content);
				
				int num = ps.executeUpdate();
				if(num>0) {
					System.out.println(num + " 개의 새글이 추가되었습니다.");
					System.out.println();
				}else {
					System.out.println("추가 작업에 실패하였습니다.");
				}
				System.out.println();
			} catch (SQLException e) {
				System.out.println("작업 실패 !! 공백없이 입력해주세요.");
//				e.printStackTrace();
			} finally {
				if(rs!=null) try { rs.close();	} catch (Exception e) { }
				if(ps!=null) try { ps.close();	} catch (Exception e) { }
				if(conn!=null) try { conn.close();	} catch (Exception e) { }

			}
			}

		//전체 리스트
	public void view() {

			System.out.println("------------------------------------");
			System.out.println("  NO     제목  	     작성자      조회수");
			System.out.println("------------------------------------");

			try {

				conn = DButil.getConnection();

				String sql = "SELECT * FROM jdbc_board ORDER BY  board_no DESC";

				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				while (rs.next()) {
					System.out.println("  " +rs.getString("board_no") +"\t"
								+ rs.getString("board_title")+"\t   "
							+ rs.getString("board_writer") +"\t   "
								+ rs.getInt("board_cnt"));
				}
				System.out.println("----------------------------------------");

			} catch (SQLException e) {
				System.out.println("전체 리스트 출력 실패~");
//				e.printStackTrace();
			}finally {
				if(rs!=null) try { rs.close(); } catch (Exception e) { }
				if(ps!=null) try { ps.close(); } catch (Exception e) { }
				if(conn!=null) try { conn.close(); } catch (Exception e) { }
		}
		
	}	//view 메서드 끝
	
}
