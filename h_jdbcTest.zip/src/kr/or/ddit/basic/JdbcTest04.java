package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcTest04 {

	// 은행 계좌번호 정보를 추가하는 예제 - insert문 사용  
	public static void main(String[] args) {

		// 데이터를 추가하기 
		Scanner scan = new Scanner(System.in);
		
		// insert문 사용시 변수 선언할 때 resultset이 필요하지 않다. 
		Connection conn = null;
		Statement stmt = null;
//		PreparedStatement pstmt = null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "sem", "java");
			
			System.out.println("계좌 전화번호 정보 추가하기 ");
			System.out.print("계좌번호 : ");
			String bankNo = scan.next();
			
			System.out.print("은행명 : ");
			String bankNm = scan.next();
			
			System.out.print("예금주 명 : ");
			String userNm = scan.next();
			
			//개설날짜는 추가되는 시간을 넣기 
//			Insert into bankinfo (bank_no, bank_name, bank_user_name, bank_date)   
//			values ('123-456-78', '하나은행', '홍길동', sysdate);
			
			
			//쿼리문을 실행 할 때 넣는다.
			String sql = "Insert into bankinfo (bank_no, bank_name, bank_user_name, bank_date) "
					+ " values ( '" + bankNo + "' , '" + bankNm + "' , '" + userNm + "' , sysdate ) ";	//문자열일 경우 ''가 있어야 하므로 주의하기
			
			System.out.println("작성한 sql문 : " + sql);
			System.out.println();
			
			//statement 객체를 이용하기
			stmt = conn.createStatement();
			
			// sql문이 select문일 경우에는 excuteQuery()메서드를 사용했는데,
			// sql문이 select문이 아닐경우에는 excuteUpdate() 메서드를 사용한다.
			
			//excuteUpdate() 메서드의 반환값 ==> 해당 작업에 성공한 레코드 수 
			int cnt = stmt.executeUpdate(sql);
			
			System.out.println("반환값 cnt : " + cnt);

		} catch (SQLException e) {
			e.printStackTrace();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(stmt!=null) try { stmt.close();	} catch (Exception e) {	}
//			if(pstmt!=null) try { pstmt.close();	} catch (Exception e) {	}
			if(conn!=null) try { conn.close();	} catch (Exception e) {	}
		}
		
		
	}

}
