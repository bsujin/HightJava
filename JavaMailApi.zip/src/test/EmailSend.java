package test;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSend {

	public static void main(String[] args) {

		try {
			Properties clsProp = System.getProperties();

			// 메일 서버 주소
			clsProp.put("mail.google.host", "mail.google.com");

			// 메일 서버 포트 번호
			clsProp.put("mail.smtp.port", 25);

			// 인증이 필요하면 아래와 같이 설정한다.
			clsProp.put("mail.smtp.auth", "true");

			Session clsSession = Session.getInstance(clsProp, new Authenticator() {

				public PasswordAuthentication getPasswordAuthentication() {
					// 인증 아이디/비밀번호를 저장한다.
					return new PasswordAuthentication("bsjin7231@gmial.com", "user_password");
				}
			});

			Message clsMessage = new MimeMessage(clsSession);

			// 발신자 이메일 주소를 설정한다.
			clsMessage.setFrom(new InternetAddress("bsjin7231@naver.com"));

			// 수신자 이메일 주소를 설정한다.
			clsMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("bsjin7231@gmail.com"));

			// 제목을 저장한다.
			clsMessage.setSubject("제목");

			// 메일 내용을 저장한다. 소스 코드를 euc-kr 로 작성하여서 charset 을 euckr 로 설정함.
			clsMessage.setContent("본문", "text/plain;charset=euckr");

			// 메일 전송
			Transport.send(clsMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
