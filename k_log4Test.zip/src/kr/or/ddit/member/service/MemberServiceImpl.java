package kr.or.ddit.member.service;

import java.util.List;
import java.util.Map;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoImpl;
import kr.or.ddit.member.vo.MemberVo;

public class MemberServiceImpl implements IMemberService{

	private IMemberDao dao;
	
	//1번 자신 class의 참조값이 저장될 변수를 private static으로 선언한다.
	private static MemberServiceImpl service;
	
	//2번 생성자의 접근 제한자를 private로 한다.
	private MemberServiceImpl() {	
		dao = MemberDaoImpl.getInstance();
	}
   
   //3번 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
	public static MemberServiceImpl getInstance() {
		if(service==null) service = new MemberServiceImpl();
		return service;
		
	}

	@Override
	public int insertMember(MemberVo memVo) {
		return dao.insertMember(memVo);
	}

	@Override
	public int deleteMember(String memId) {
		return dao.deleteMember(memId);
	}

	@Override
	public int updateMember(MemberVo memVo) {
		return dao.updateMember(memVo);
	}

	@Override
	public List<MemberVo> getAllMemberList() {
		return dao.getAllMemberList();
	}

	@Override
	public int getMemberCount(String memId) {
		return dao.getMemberCount(memId);
	}

	@Override
	public int updateMember2(Map<String, String> paramMap) {
		return dao.updateMember2(paramMap);
	}
	

}
