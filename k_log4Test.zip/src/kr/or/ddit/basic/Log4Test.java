package kr.or.ddit.basic;


import org.apache.log4j.Logger;

public class Log4Test {
	// Logger클래스의 인스턴스 생성하기 			현재 클래스를 써준다
	static Logger logger = Logger.getLogger(Log4Test.class);

	public static void main(String[] args) {
		// log 기록 출력하기 (log의 메세지)
		
		// 방법 1
		logger.trace("이 메세지는 trace 레벨의 메시지입니다.");
		logger.debug("이 메세지는 debug 레벨의 메시지입니다.");
		logger.info("이 메세지는 information 레벨의 메시지입니다.");
		logger.warn("이 메세지는 Warnning 레벨의 메시지입니다.");
		logger.error("이 메세지는 Error 레벨의 메시지입니다.");
		logger.fatal("이 메세지는 Fatal 레벨의 메시지입니다.");
		
//		// 방법2   : Level.레벨
		
//		logger.log(Level.FATAL, "이 메세지는 Fatal 레벨의 메시지입니다.");
//		logger.log(Level.DEBUG, "이 메세지는 debug 레벨의 메시지입니다.");
//		logger.log(Level.INFO, "이 메세지는 information 레벨의 메시지입니다.");
//		logger.log(Level.WARN, "이 메세지는 warnning 레벨의 메시지입니다.");
//		logger.log(Level.TRACE, "이 메세지는 trace 레벨의 메시지입니다.");
		
		
	}

}
