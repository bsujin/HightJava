package kr.or.ddit.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.member.action.MemberListAction;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.vo.MemberVO;

public class WebController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		/*
		 * URL : http://localhost/servletTest2/member/memberList.do URI :
		 * /servletTest2/member/memberList.do ContextPath ==> /servletTest2
		 * 
		 * CONTEXTpath 가 필요한 이유 -> 프로젝트를 어디서 하든 프로젝트를 찾아준다. (servletTest2 가 contextPath)
		 * 중간에 들어가는 member
		 * 
		 * 원하는 요청 URI ==> /member/memberList.do
		 */

		// 사용자의 요청 정보 가져오기
		String uri = request.getRequestURI(); // url정보 가져오기
		uri = uri.substring(request.getContextPath().length());

		String viewPage = null; // view페이지가 저장될 변수 선언
		IAction action = null;

		// 요청 URI를 이용하여 실행할 Action의 값 구한다.
		action = URIActionMapper.getAction(uri);

		if (action == null) {
			// 실행할 Action이 없으면 404에러 처리
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		} else {
			// 실행 작업 완료 후 View페이지를 받는다. (호출)
			viewPage = action.process(request, response);	//memberListAction

			if (viewPage != null) {
				if (action.isRedirect()) { // 리다이렉트가 true일 경우
					response.sendRedirect(request.getContextPath() + viewPage);
				} else {	// 포워딩
					RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view" + viewPage);
					rd.forward(request, response);
				}
			}
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
