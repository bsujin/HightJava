package kr.or.ddit.board.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import kr.or.ddit.board.vo.JdbcBoardVO;

public class JdbcBoardDaoImpl implements IJdbcBoardDao{
	private static JdbcBoardDaoImpl dao;
	private SqlMapClient smc; 
	private Reader rd;
	
	private JdbcBoardDaoImpl() {
		try {
			// 1-1. 문자 인코등 캐릭터 셋 설정
			Charset charset = Charset.forName("UTF-8");
			Resources.setCharset(charset);

			// 1-2 환경 설정 파일을 읽어온다.
			rd = Resources.getResourceAsReader("sqlMapConfig.xml");

			// 1-3. 위에서 읽어온 Reader객체를 이용하여 실제 환경설정을 완성한 후
			// SQL문을 호출해서 실행할 수 있는 객체를 생성한다.
			smc = SqlMapClientBuilder.buildSqlMapClient(rd);

			rd.close();

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (rd != null)		try {	rd.close();	} catch (IOException e) {	}
		
	}
	}
	
	public static JdbcBoardDaoImpl getInstance() {
		if(dao==null) dao = new JdbcBoardDaoImpl();
		return dao;
	}
	
	// DB작업에 필요한 객체 변수 선언
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	// 사용한 자원을 반납하는 메서드
	private void disconnect() {
		if(rs!=null) try { rs.close(); } catch(SQLException e) {}
		if(stmt!=null) try { stmt.close(); } catch(SQLException e) {}
		if(pstmt!=null) try { pstmt.close(); } catch(SQLException e) {}
		if(conn!=null) try { conn.close(); } catch(SQLException e) {}
	}
	

	//입력 
	@Override
	public int insertBoard(JdbcBoardVO boardVo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("board.insertBoard",boardVo);
			if(obj==null) cnt=1;
		
			
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}

	//삭제
	@Override
	public int deleteBoard(int boardNo) {
		int cnt = 0;
		try {
			
			cnt = smc.delete("board.deleteBoard", boardNo);
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}

	//수정
	@Override
	public int updateBoard(JdbcBoardVO boardVo) {
		int cnt = 0;
		
		try {
			cnt = smc.update("board.updateBoard",boardVo);
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}
		
		return cnt;
	}
	
	//전체 리스트 출력 
	@Override
	public List<JdbcBoardVO> getAllBoardList() {
		List<JdbcBoardVO> boardList = null;
		
		
		try {

			boardList = smc.queryForList("board.getAllList");

		} catch (SQLException e) {
			boardList = null;
			e.printStackTrace();
		} 
		
		return boardList;
	}
	//선택 조회하기
	@Override
	public JdbcBoardVO getBoard(int boardNo) {
		JdbcBoardVO boardVo = null;
		
		try {
//레코드가 한개일 경우 - object , 여러개일 경우 list
			boardVo = (JdbcBoardVO) smc.queryForObject("board.getBoard", boardNo);
			
		} catch (SQLException e) {
			boardVo = null;
			e.printStackTrace();
		} 
		return boardVo;
	}
	
//검색할 제목을 입력
	@Override
	public List<JdbcBoardVO> getSearchBoardList(String title) {
		List<JdbcBoardVO> boardList = null;
		
		try {
			boardList = smc.queryForList("board.getSearchBoard", title);
			
		} catch (SQLException e) {
			boardList = null;
			e.printStackTrace();
		}
		return boardList;
	}

	@Override
	public int setCountIncrement(int boardNo) {
		int cnt = 0;
		
		try {
			
			cnt = smc.update("board.updateCount",boardNo);
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}
		
		return cnt;
	}
	

}
