package kr.or.ddit.member.dao;

import java.io.Reader;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.utill.BuildedSqlMapClient;

public class MemberDaoImpl implements IMemberDao {

	private SqlMapClient smc; // iBatis용 sqlMapClient 객체 변수 선언
	private Reader rd;

	// 1. 자신 Class의 참조값이 저장될 변수를 private static으로 선언한다.
	private static MemberDaoImpl dao;

	// 2. 생성자의 접근 제한자를 private으로 한다.
	// DAO의 생성자에서 iBatis환경설정과 sqlMapClient 객체를 생성한다.
	private MemberDaoImpl() {

		/*
		 * try { // 1-1. 문자 인코등 캐릭터 셋 설정 Charset charset = Charset.forName("UTF-8");
		 * Resources.setCharset(charset);
		 * 
		 * // 1-2 환경 설정 파일을 읽어온다. rd =
		 * Resources.getResourceAsReader("sqlMapConfig.xml");
		 * 
		 * // 1-3. 위에서 읽어온 Reader객체를 이용하여 실제 환경설정을 완성한 후 // SQL문을 호출해서 실행할 수 있는 객체를
		 * 생성한다. smc = SqlMapClientBuilder.buildSqlMapClient(rd);
		 * 
		 * rd.close();
		 * 
		 * }catch(IOException e){ e.printStackTrace(); }finally { if(rd!=null) try {
		 * rd.close(); } catch(IOException e) { } }
		 */

		smc = BuildedSqlMapClient.getSqlMapClient();
	}

	// 3. 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
	// ( 이 메서드의 이름은 보통 getInstance()로 한다. )
	public static MemberDaoImpl getInstance() {
		if (dao == null)
			dao = new MemberDaoImpl();
		return dao;
	}

	// 작성

	@Override
	public int insertMember(MemberVO memVo) {
		int cnt = 0; // 반환값이 저장될 변수 ( 작업성공 : 1, 실패 : 0)

		try { // namespace명.id명
			Object obj = smc.insert("mymember.insertMember", memVo);
			if (obj == null)
				cnt = 1; // 성공하면 null이므로 1로 반환되어 결과 성공값으로 바뀐다.

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// 삭제
	@Override
	public int deleteMember(String memId) {
		int cnt = 0; // 반환값이 저장될 변수 ( 작업성공 : 1, 실패 : 0)

		try {
			cnt = smc.delete("mymember.deleteMember", memId);
			// 반환값이 1, 실패시 0이므로 굳이 비교해줄 필요가 없음

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// 수정
	@Override
	public int updateMember(MemberVO memVo) {
		int cnt = 0; // 반환값이 저장될 변수 ( 작업성공 : 1, 실패 : 0)

		try {
			cnt = smc.update("mymember.updateMember", memVo);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	// 전체 회원정보를 출력
	@Override
	public List<MemberVO> getAllMemberList() {

		List<MemberVO> memList = null; // MemberVo객체가 저장될 List객체 변수 선언

		try {

			memList = smc.queryForList("mymember.getAllMember"); // 파라미터 클래스가 없으므로 ,뒤에 안써줘도 된다

		} catch (SQLException e) {
			memList = null;
			e.printStackTrace();
		}
		return memList;
	}

	// COUNT

	@Override
	public int getMemberCount(String memId) {
		int cnt = 0;
		try {
			// queryForObject를 사용할때에는 항상 형변환을 해줘야한다 -> 반환값이 int이므로 count에 담아줘야된다.

			cnt = (int) smc.queryForObject("mymember.getCount", memId);

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	@Override
	public int updateMember2(Map<String, String> paramMap) {
		// Map의 key값 : 회원 ID(memId), 변경할 컬럼명(field), 변경한 데이터(data)
		int cnt = 0;
		try {
			cnt = smc.update("mymember.updateMember2", paramMap);

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}
		return cnt;
	}

}
