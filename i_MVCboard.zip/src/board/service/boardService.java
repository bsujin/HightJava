package board.service;

import java.util.List;

import board.dao.boardDao;
import board.vo.boardVo;

public class boardService implements IboardService{

private boardDao dao;
	
	//1번 자신 class의 참조값이 저장될 변수를 private static으로 선언한다.
	private static boardService service;
	
	//2번 생성자의 접근 제한자를 private로 한다.
	private boardService() {
		dao = boardDao.getInstance();
	}	
   
   //3번 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
	public static boardService getInstance() {
		if(service==null) service = new boardService();
		return service;
		
	}

	
	@Override
	public int insertBoard(boardVo bVo) {
	return dao.insertBoard(bVo);
	}

	@Override
	public int deleteBoard(int boardNo) {
		return dao.deleteBoard(boardNo);
	}

	@Override
	public int updateBoard(boardVo bVo) {
		return dao.updateBoard(bVo);
	}

	@Override
	public List<boardVo> getAllBoardList() {
		return dao.getAllBoardList();
	}

	@Override
	public List<boardVo> getsearchList(int boardNo) {
		return dao.getsearchList(boardNo);
	}

	@Override
	public int getBoardCount(int boardNo) {
		return dao.getBoardCount(boardNo);
	}

	@Override
	public int updateConut(int boardNo) {
		return dao.updateConut(boardNo);
	}

	@Override
	public List<boardVo> getBoardsearch(String title) {
		// TODO Auto-generated method stub
		return dao.getBoardsearch(title);
	}
	

}
