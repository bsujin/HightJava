package board.vo;
/**
 *  VO는 DB테이블에 있는 컬럼명을 기준으로 데이터를 객체화 할 클래스이다.
 *  DB테이블의 '컬럼명'이  이 VO 클래스의 '멤버변수명'이 된다.
 *	
 *	DB테이블의 컬럼과 클래스의 멤버 변수를 매칭하는 역할을 수행한다. 
 *
 */
public class boardVo {
	
	private int boardNo;	//게시글번호
	private String title;	//게시글 제목
	private String writer;	//작성자
	private String date;	//작성날짜
	private int cnt;		//조회수
	private String content;	//내용
	
	
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	

}
