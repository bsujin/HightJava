package board.main;

import java.util.List;
import java.util.Scanner;
import board.service.IboardService;
import board.service.boardService;
import board.vo.boardVo;

public class BoardController {
	private IboardService service; // Service 객체가 저장될 변수 선언
	private Scanner scan = new Scanner(System.in);

	// 생성자 (Controller)
	public BoardController() {
//		service = new board.service();
		service = boardService.getInstance();
	}
	
	int menu = 0;
	public static void main(String[] args) {

		new BoardController().start();
		
		
	}

	private void start() {
		
		
		while (true) {
			
			if (menu == 0) {
				view();
			}

			System.out.println(" 메뉴 : 1. 새글작성       2. 게시글 보기      3.검색       0. 작업끝");
			System.out.print(" 작업 선택 >> ");


			int input = Integer.parseInt(scan.nextLine());
			
		
		
			switch (input) {
			case 1:
				write();
				break;
			
			case 2 : 
				boardList();
				break;

			case 3 : 
				search();
				break;

			default:
				System.out.println("잘못입력했습니다. 다시 입력해주세요.");
				break;
			}//switch 문 끝
			
		}	//while문 끝
	}

	//전체 리스트
		public void view() {

			//반환값을 저장할 리스트 
			List<boardVo>boardList = service.getAllBoardList();
			
				System.out.println("------------------------------------");
				System.out.println("  NO     제목  	     작성자      조회수");
				System.out.println("------------------------------------");

				if(boardList==null || boardList.size()==0) {
					System.out.println(" 게시글이 없습니다.");
				}else {

				for (boardVo bVo : boardList) {
					int boardNo = bVo.getBoardNo();
					String title = bVo.getTitle();
					String writer = bVo.getWriter();
					int cnt = bVo.getCnt();

			System.out.println(boardNo + "\t" + title + "\t" + writer + "\t" + cnt);
				}
			}
				System.out.println("--------------------------------------");
			}
			
			//view 메서드 끝
	
		//게시판에 글을 작성하는 메서드 
		private void write() {
			
				
					System.out.println("게시판에  작성할 글을 입력해주세요");
					System.out.print(" 제목 >>");
					String title = scan.nextLine();
					
					System.out.print(" 작성자 >>");
					String writer = scan.nextLine();
					
					System.out.println(" 내용>>");
					String content = scan.nextLine();
					
				
					// 입력한 회원정보를 저장할 boardVo 객체생성 -> 객체에 담아서 넣어주기
					boardVo bVo = new boardVo();

					// 입력한 데이터를 boardVo객체에 저장한다
					bVo.setTitle(title);
					bVo.setWriter(writer);
					bVo.setContent(content);

					// service객체에서 회원 정보를 추가하는 매서드 호출하기
					int cnt = service.insertBoard(bVo);

					if (cnt > 0) {
						System.out.println("추가 성공 !!");
					} else {
						System.out.println("추가 작업 실패 ~~~");
					}
					
				}
		
	// 게시글을 보는 메서드
	private void boardList() {

		System.out.println();
		System.out.print("보기를 원하는 게시물 번호 입력 >>");
		int boardNo = Integer.parseInt(scan.nextLine());


		service.updateConut(boardNo); // 조회수 업데이트
		List<boardVo> boardList = service.getsearchList(boardNo); //조회한 게시글 가져오기

		System.out.println("------------------------------------");

		if (boardList == null || boardList.size() == 0) {
			System.out.println(" 게시글이 없습니다.");
			return;
		} else {

			for (boardVo bVo : boardList) {
				boardNo = bVo.getBoardNo();
				String title = bVo.getTitle();
				String writer = bVo.getWriter();
				String content = bVo.getContent();
				String date = bVo.getDate();
				int cnt = bVo.getCnt();

				System.out.println(" - 제목 : " + title + 
						"\n - 작성자 : " + writer + 
						" \n - 내용 : " + content
						+ " \n - 작성일 : " + date + 
						" \n - 조회수 : " + cnt);
			} // for문 종료
		}
		
		System.out.println("--------------------------------------");
	
			
			System.out.println("메뉴 : 1.수정      2.삭제     3.리스트로 가기  ");
			System.out.println("메뉴를 입력하세요>>");
			int input = Integer.parseInt(scan.nextLine());
			switch (input) {
			case 1:
				update(boardNo);
				break;
			case 2 :
				delete(boardNo);
				break;
			case 3 :
				return;	//반복문을 받고있으므로 이전으로 가기 
			default:
				System.out.println("잘못입력했습니다. 다시 입력해주세요.");
				break;
				
			} //switch문 종료
	}
	
	// 삭제하는 메서드
		private void delete(int boardNo) {
			
			int cnt = service.deleteBoard(boardNo);
			if(cnt>=1) {
				System.out.println(boardNo + " 번 글이 삭제 되었습니다.");
				}else {
					System.out.println("게시글 삭제에 실패했습니다.");
				}
				System.out.println();
				
			}
			

	// 수정하는 메서드 
		private void update(int boardNo) {
			boardVo bVo = new boardVo();
			
				System.out.println("수정 작업하기");
				System.out.println("------------------------");
				System.out.println("수정할 제목을 입력해주세요 >> ");
				String title = scan.nextLine();
				System.out.println("수정할 내용을 입력해주세요 >> ");
				String content = scan.nextLine();

				bVo.setTitle(title);
				bVo.setContent(content);
								
				
				int cnt = service.updateBoard(bVo);
				if (cnt >= 1) {
					System.out.println(boardNo +"번 글이 수정 되었습니다.");
				} else {
					System.out.println("게시글 수정에 실패했습니다.");
				}
				System.out.println();
				
			}
	
		//게시글을 검색하는 메서드 
		private void search() {
			
			System.out.println("검색 작업");
			System.out.println("--------------------------------------");
			System.out.print("검색할 제목 입력 >>");
			String title = scan.nextLine();
			
			if(title.equals(" ")) {		// 공백을 입력했을 시 전체 게시글 조회
				menu = 0;
				return;
			} else {
			
				menu = 1;
					
						
				System.out.println();
				System.out.println("======================================");
				System.out.println(" NO\t제 목\t\t작성자\t조회수");
				System.out.println("======================================");
				
				List<boardVo> searchList = service.getBoardsearch(title);
				
				for(boardVo bVo : searchList) {
					int boardno = bVo.getBoardNo();
					String boardtitle = bVo.getTitle();
					String boardwriter = bVo.getWriter();
					int boardcnt = bVo.getCnt();
					
					System.out.println(" " + boardno + "\t" + 
									boardtitle + "\t\t" + boardwriter + "\t"
									+ boardcnt);
				}
				System.out.println("======================================");
			}
		}
}