package board.dao;

import java.util.List;

import board.vo.boardVo;

public interface IboardDao {
	
	// 실제 db와 연결해서 어떤 작업을 할지, 작업에 필요한 데이터가 무엇인지, 데이터의 결과를 어떻게 보낼지 생각하기

	/**
	 * boardVO에 담겨진 자료를 DB에 insert하는 메서드
	 * 
	 * @param bVo
	 *            DB에 insert할 자료가 저장된 boardVO객체
	 * @return insert작업 성공 : 1, 실패 : 0
	 * 
	 */

	// insert 작업 -> insert할 데이터는 controller에서 만들기
	public int insertBoard(boardVo bVo);

	/**
	 * 게시반번호를 매개값으로 받아서 해당 회원 정보를 삭제하는 메서드
	 * 
	 * @param boardNo
	 *            삭제할 게시글번호
	 * @return 삭제성공 : 1, 삭제 실패 : 0
	 * 
	 */

	// 삭제 작업 : 회원 아이디로 삭제
	public int deleteBoard(int boardNo);

	/**
	 * boardVO에 담겨진 정보를 이용하여 회원 정보를 수정하는 메서드
	 * 
	 * @param boardNo
	 *            수정할 정보가 저장된 MemVO객체
	 * @return 수정성공 : 1, 수정 실패 0 ;
	 * 
	 */

	// 수정작업 : id를 제외한 나머지 정보
	public int updateBoard(boardVo bVo);

	/**
	 * DB의 게시판의 전체 글을 가져와서 List에 담아서 반환하는 메서드
	 * 
	 * @return boardVo의 객체를 담고있는 List객체
	 */

	// 전체 자료 출력 : dao에서 select로 가져온 데이터를 collection(list)에 담아서 보낸다.
	public List<boardVo> getAllBoardList();

	/**
	 * 게시판의 전체 글중 번호로 검색하여 list에 담아서 반환하는 메서드
	 * 
	 * @param boardNo
	 * @return
	 */
	// 원하는 게시물 검색 : dao에서 no로 조회한 데이터를 list에 담아서 보낸다
	public List<boardVo> getsearchList(int boardNo);

	/**
	 * 게시글번호를 매개값으로 받아서 해당 게시글을 반환하는 메서드
	 * 
	 * @param boardNo
	 * @return
	 */
	public int getBoardCount(int boardNo);

	/**
	 * 조회수가 없데이트 되는 메서드
	 * 
	 * @param boardNo
	 * @return
	 */
	public int updateConut(int boardNo);
	
	/**
	 * 검색한 것을 매개값으로 받아서 해당 게시글의 정보를 List에 담아서 변환하는 메소드 
	 * @param title		검색한 게시글 제목
	 * @return		BoardVO객체를 담고 있는 List객체
	 */
	public List<boardVo> getBoardsearch(String title);

}
