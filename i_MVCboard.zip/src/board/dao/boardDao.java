package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import board.vo.boardVo;
import util.DButil3;

//다오는 쿼리문 하나 매서드 하나

public class boardDao implements IboardDao {

	// 1. 자신 Class의 참조값이 저장될 변수를 private static으로 선언한다.
	private static boardDao dao;

	// 2. 생성자의 접근 제한자를 private으로 한다.
	private boardDao() {
	}

	// 3. 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
	// ( 이 메서드의 이름은 보통 getInstance()로 한다. )
	public static boardDao getInstance() {
		if (dao == null)
			dao = new boardDao();
		return dao;
	}

	// 작성
	@Override
	public int insertBoard(boardVo bVo) {
	Connection conn = null;
		PreparedStatement ps = null;
		int cnt = 0; // 반환값이 저장될 변수 ( 작업성공 : 1, 실패 : 0)

		try {
			conn = DButil3.getConnection();

			// Insert into jdbc_board (board_no, board_title, board_writer, board_date,
			// board_cnt, board_content)
			// values (3, '제목', '나나', sysdate, 0, 'fff');

			String sql = " Insert into jdbc_board values (board_seq.nextVal , ? , ? ,sysdate, 0, ?)";

			ps = conn.prepareStatement(sql);
			ps.setString(1, bVo.getTitle());
			ps.setString(2, bVo.getWriter());
			ps.setString(3, bVo.getContent());

			cnt = ps.executeUpdate();

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			if (ps != null)
				try {
					ps.close();
				} catch (Exception e) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
				}

		}
		return cnt;
	}

	// 데이터를 조회 
	@Override
	public List<boardVo>getsearchList(int boardNo) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		List<boardVo>searchList = null;
		
		try {
			conn = DButil3.getConnection();

			//조회하는 sql문 
			String sqlView= "SELECT * FROM jdbc_board WHERE board_no = ?";
			ps = conn.prepareStatement(sqlView); 
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();
			searchList = new ArrayList<boardVo>();
			while (rs.next()) {
				boardVo bVo = new boardVo();
				
				
				bVo.setTitle(rs.getString("board_title"));
				bVo.setWriter(rs.getString("board_writer"));
				bVo.setDate(rs.getString("board_date"));
				bVo.setCnt(rs.getInt("board_cnt"));
				bVo.setContent(rs.getString("board_content"));
		
				searchList.add(bVo);
			}

			
		} catch (SQLException e) {
			searchList = null;
			e.printStackTrace();
		} finally {		
			if (rs != null)		try {	rs.close();	} catch (Exception e) { }
			if (ps != null)		try {	ps.close();	} catch (Exception e) {	}
			if (conn != null)	try {conn.close();	} catch (Exception e) {	}
		}
		return searchList;
	}
	
	//게시글번호를 매개값으로 받아서 해당 게시글을 반환하는 메서드 
	
	@Override
	public int getBoardCount(int boardNo) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int cnt = 0;
		
		try {
			
			conn = DButil3.getConnection();
			String sql = "Select count(*) cnt from jdbc_board WHERE board_no = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();
			
		
			
		} catch (SQLException e) {
			cnt=0;
			e.printStackTrace();
		} finally {		
			if (rs != null)		try {	rs.close();	} catch (Exception e) { }
			if (ps != null)		try {	ps.close();	} catch (Exception e) {	}
			if (conn != null)	try {conn.close();	} catch (Exception e) {	}
		}
		return cnt;
	}
	
	

	// 삭제
	@Override
	public int deleteBoard(int boardNo) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		int cnt = 0; // 반환값이 저장될 변수 ( 작업성공 : 1, 실패 : 0)

		try {
			conn = DButil3.getConnection();

			String sql = "DELETE jdbc_board WHERE board_no = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);

			cnt = ps.executeUpdate();

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			if (ps != null)	try {	ps.close();	} catch (Exception e) {	}
			if (conn != null)	try {	conn.close();} catch (Exception e) {}
		}
		return cnt;
	}

	// 수정
	@Override
	public int updateBoard(boardVo bVo) {

		Connection conn = null;
		PreparedStatement ps = null;
		int cnt = 0; // 반환값이 저장될 변수 ( 작업성공 : 1, 실패 : 0)

		try {
			conn = DButil3.getConnection();

			String sql = "UPDATE jdbc_board SET board_title = ?, board_content = ? WHERE board_no =?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, bVo.getTitle());
			ps.setString(2, bVo.getContent());
			ps.setInt(3, bVo.getBoardNo());

			cnt = ps.executeUpdate();

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}finally {
			if (ps != null)	try {	ps.close();	} catch (Exception e) {	}
			if (conn != null)	try {	conn.close();} catch (Exception e) {}
		}

		return cnt;
	}

	@Override
	public List<boardVo> getAllBoardList() {

		List<boardVo> boardList = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int cnt = 0;

		try {

			conn = DButil3.getConnection();

			String sql = "SELECT * FROM jdbc_board ORDER BY  board_no DESC";

			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			boardList = new ArrayList<>(); // List객체 생성
			while (rs.next()) {

				// 객체 생성
				boardVo bVo = new boardVo();

				// ResultSet 객체의 데이터를 가져와서 넣기
				bVo.setBoardNo(rs.getInt("board_no"));
				bVo.setTitle(rs.getString("board_title"));
				bVo.setWriter(rs.getString("board_writer"));
				bVo.setCnt(rs.getInt("board_cnt"));

				boardList.add(bVo);

			}
			cnt = ps.executeUpdate();
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}finally {
			if (rs != null)	try {	rs.close();	} catch (Exception e) {	}
			if (ps != null)	try {	ps.close();	} catch (Exception e) {	}
			if (conn != null)	try {	conn.close();} catch (Exception e) {}
		}
	
		return boardList;
	}

	//조회수를 업데이트 하는 메서드 
	@Override
	public int updateConut(int boardNo) {
		Connection conn = null;
		PreparedStatement ps = null;
		int cnt = 0;
		
		//조회수가 증가되는 SQL문 
//		UPDATE JDBC_BOARD SET BOARD_CNT = BOARD_CNT+1  WHERE BOARD_NO = 1;
		try {
			conn = DButil3.getConnection();

		String sql = " UPDATE JDBC_BOARD SET BOARD_CNT = BOARD_CNT+1 WHERE board_no = ?"; 
		
		ps = conn.prepareStatement(sql);
		ps.setInt(1, boardNo);
		
		cnt = ps.executeUpdate();
		
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}finally {
		if(ps!=null) try { ps.close();	} catch (Exception e) { }
		if(conn!=null) try { conn.close();	} catch (Exception e) { }
		}
		return cnt;
}

	@Override
	public List<boardVo> getBoardsearch(String title) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		List<boardVo> boardList = null;
		
		try {
			
			conn = DButil3.getConnection();
			
			String sql = "SELECT * FROM jdbc_board WHERE board_title LIKE '%" + title +"%' ORDER BY board_no DESC";
			
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			boardList = new ArrayList<boardVo>();
			while(rs.next()) {
				boardVo bVo = new boardVo();
				
				bVo.setBoardNo(rs.getInt("board_no"));
				bVo.setTitle(rs.getString("board_title"));
				bVo.setWriter(rs.getString("board_writer"));
				bVo.setCnt(rs.getInt("board_cnt"));
				
				boardList.add(bVo);
			}
			
		} catch (SQLException e) {
			boardList = null;
			e.printStackTrace();
		} finally {
			if( rs != null) try { rs.close(); } catch(SQLException e) { }
			if( st != null) try { st.close(); } catch(SQLException e) { }
			if( conn != null) try { conn.close(); } catch(SQLException e) { }
		}
		
		
		return boardList;
	}

	}


