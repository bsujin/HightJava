package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Vo.JdbcBoardVO;
import util.DButil3;

public class JdbcBoardDaoImpl implements IJdbcBoardDao {

	private static JdbcBoardDaoImpl dao;
	
	private JdbcBoardDaoImpl() { }
	
	public static JdbcBoardDaoImpl getInstance() {
		if(dao == null) dao = new JdbcBoardDaoImpl();
		return dao;
	}
	
	// DB작업에 필요한 객체 변수 선언
	private Connection conn;
	private Statement st;
	private PreparedStatement ps;
	private ResultSet rs; 
	
	// 사용한 자원을 반납하는 메소드 
	private void disconnect() {
		if(rs != null) try { rs.close(); } catch(SQLException e) { }
		if(ps != null) try { ps.close(); } catch(SQLException e) { }
		if(st != null) try { st.close(); } catch(SQLException e) { }
		if(conn != null) try { conn.close(); } catch(SQLException e) { }
	}
	
	@Override
	public int insertBoard(JdbcBoardVO boardVo) {
		
		int cnt = 0;
		
		try {
			conn = DButil3.getConnection();
			
			String sql = "INSERT INTO jdbc_board (board_no, board_title, board_writer, board_date, board_cnt, board_content) VALUES "
					+ " ( board_seq.nextval , ?, ?, SYSDATE, 0, ? )";
			
			ps = conn.prepareStatement(sql);
			ps.setString(1, boardVo.getBoard_title());
			ps.setString(2, boardVo.getBoard_writer());
			ps.setString(3, boardVo.getBoard_content());
			
			cnt = ps.executeUpdate();
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			disconnect();	// 자원 반납하는 메소드
			
		}
		return cnt;
	}

	@Override
	public int deleteBoard(int boardNo) {
		int cnt = 0;
		try {
			conn = DButil3.getConnection();
			
			String sql = "DELETE FROM jdbc_board WHERE board_no = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			
			cnt = ps.executeUpdate();
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}

	@Override
	public int updateBoard(JdbcBoardVO boardVo) {
		int cnt = 0;
		
		try {
			conn = DButil3.getConnection();
			
			String sql = "UPDATE jdbc_board set "
					+ " board_title = ? , board_date = SYSDATE, board_content = ? WHERE board_no = ? "; 
			ps = conn.prepareStatement(sql);
			ps.setString(1, boardVo.getBoard_title());
			ps.setString(2, boardVo.getBoard_content());
			ps.setInt(3, boardVo.getBoard_no());
			
			cnt = ps.executeUpdate();
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		
		return cnt;
	}

	@Override
	public List<JdbcBoardVO> getAllBoardList() {
		
		List<JdbcBoardVO> boardList =  null;
		
		try {
			conn = DButil3.getConnection();
			String sql = "SELECT board_no, board_title, board_writer, " 
						+ " to_char(board_date, 'YYYY-MM-DD') board_date, "
						+ " board_cnt, board_content FROM jdbc_board ORDER BY board_no DESC";
			
			st = conn.createStatement();
			
			rs = st.executeQuery(sql);
			
			boardList = new ArrayList<>();
			while(rs.next()) {
				JdbcBoardVO boardVo = new JdbcBoardVO();
				
				boardVo.setBoard_no(rs.getInt("board_no"));
				boardVo.setBoard_title(rs.getString("board_title"));
				boardVo.setBoard_writer(rs.getString("board_writer"));
				boardVo.setBoard_date(rs.getString("board_date"));
				boardVo.setBoard_cnt(rs.getInt("board_cnt"));
				boardVo.setBoard_content(rs.getString("board_content"));
				
				boardList.add(boardVo);
			}
			
		} catch (SQLException e) {
			boardList = null;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		
		return boardList;
	}

	@Override
	public JdbcBoardVO getBoard(int boardNo) {
		JdbcBoardVO boardVo = null;
		try {
			conn = DButil3.getConnection();
			String sql = "SELECT board_no, board_title, board_writer, " + 
					" to_char(board_date, 'YYYY-MM-DD') board_date, " + 
					" board_cnt, board_content FROM jdbc_board WHERE board_no = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				boardVo = new JdbcBoardVO();
				
				boardVo.setBoard_no(rs.getInt("board_no"));
				boardVo.setBoard_title(rs.getString("board_title"));
				boardVo.setBoard_writer(rs.getString("board_writer"));
				boardVo.setBoard_date(rs.getString("board_date"));
				boardVo.setBoard_cnt(rs.getInt("board_cnt"));
				boardVo.setBoard_content(rs.getString("board_content"));
				
			}
			
		} catch (SQLException e) {
			boardVo = null;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return boardVo;
	}

	@Override
	public List<JdbcBoardVO> getSearchBoardList(String title) {
		
		List<JdbcBoardVO> boardList =  null;
		
		try {
			conn = DButil3.getConnection();
			
			String sql = "SELECT board_no, board_title, board_writer, " 
					+ " to_char(board_date, 'YYYY-MM-DD') board_date, "
					+ " board_cnt, board_content FROM jdbc_board "
					+ " WHERE board_title like '%' || ? || '%' " 
					+ " ORDER BY board_no DESC";
			
			ps = conn.prepareStatement(sql);
			ps.setString(1, title);
			
			rs = ps.executeQuery();
			
			boardList = new ArrayList<>();
			
			while(rs.next()) {
				JdbcBoardVO boardVo = new JdbcBoardVO();
				
				boardVo.setBoard_no(rs.getInt("board_no"));
				boardVo.setBoard_title(rs.getString("board_title"));
				boardVo.setBoard_writer(rs.getString("board_writer"));
				boardVo.setBoard_date(rs.getString("board_date"));
				boardVo.setBoard_cnt(rs.getInt("board_cnt"));
				boardVo.setBoard_content(rs.getString("board_content"));
				
				boardList.add(boardVo);
			}
			
		} catch (SQLException e) {
			boardList = null;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return boardList;
	}

	@Override
	public int setCountincrement(int boardNo) {
		int cnt = 0;
		
		try {
			conn = DButil3.getConnection();
			
			String sql = "UPDATE jdbc_board SET "
					+ " board_cnt = board_cnt + 1 "
					+ " WHERE board_no = ? ";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			
			cnt = ps.executeUpdate();
			
		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}
	
	
	

}
