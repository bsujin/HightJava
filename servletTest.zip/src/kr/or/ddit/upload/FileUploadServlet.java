package kr.or.ddit.upload;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/*
 	- Servlet 3.0이상에서 파일 업로드를 사용하려면 서블릿에 @MultiPartConfig 에노테이션을 설정해야 한다.
 	
 	- @MultipartConfig 에노테이션의 설정할 변수들 
 	1. fileSizeThreshold ==> 업로드 파일을 서버에서 처리할 때 임시기억장소(버퍼)를 사용하는데
 			==> 이 속성에서 지정한 파일크기 이하의 파일은 메모리를 사용하고 초과되는 파일은 디스크에 직접 사용한다.
 	2. maxFileSize ==> 업로드 파일의 최대 크기를 설정한다.
 	3. maxRequestSize ==> 업로드 파일 데이터가 포함된 multipart/form-data 요청의 최대 크기를 설정한다.
 	4. location ==> 파일이 저장될 디렉토리 경로를 설정한다. (생략가능)
 	--> 4번외에 나머지도 생략은 가능하나 파일의 크기를 설정해주는것이 좋다.
 	
 	-- 위의 변수에 설정하는 파일 크기는 byte단위로 설정한다.
 	 1024byte => 1kb, 1mb  ==> 1024 * 1024 * 10 : 10mb  
 */
@WebServlet("/filUploadServlet.do")
@MultipartConfig(fileSizeThreshold=1024 * 1024 * 10, maxFileSize=1024*1024*30, maxRequestSize=1024*1024*50)
public class FileUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private final String UPLOAD_DIR = "uploadFiles";		//업로드 된 파일이 저장될 폴더 명  -> 자식

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//사용자가 업로드한 파일이 저장될 서버 쪽의 폴더 경로 설정
		//이렇게 사용할 경우 따로따로 지정이 가능하여 관리하기 용이하다    -> 부모 
		String applicationPath = "D:/D_Other";
		String uploadPath = applicationPath + File.separator + UPLOAD_DIR;
		
		//	방법2 	위에 폴더명에 같이 지정해도 된다.    : 	String uploadPath = "D:/D_other/uploadFiles";
		
		//저장될 폴더가 없으면 새로 생성한다.
		File uploadDir = new File(uploadPath);
		if(!uploadDir.exists()) {
			uploadDir.mkdirs();
		}
		
		// 파일이 아닌 데이터는 getParameter()메서드나 getParameterValues()메서드를  이용해서 구한다.
		request.setCharacterEncoding("utf-8");
		String memId = request.getParameter("memId");
		System.out.println("파일이 아닌 데이터 :" + memId);
		
		//-----------------------------------
		
		//파일 데이터 사용하기
		String fileName = "";		//파일 명이 저장될 변수
		List<FileDetailVO> fileList = new ArrayList<>();	//업로드한 파일 정보가 저장될 변수
		
		/*
		 	- Servlet 3.0이상에 새롭게 추가된 파일  Upload용 메서드들
		 	1. request.getParts(); ==> Part객체의 컬렉션을 반환한다.
		 	2. request.getPart("Part이름"); ==> 지정된 이름을 가진 개별 Part객체를 반환한다.
		 	
		 	 --Part 객체의 구조 --
		 	 1. 파일이 아닐 경우
		 	 -----문자문자자자ㅏ자아아아내용 			==> Part를 구분하는 구분선 ---- ,  웹브라우저 마다 다르게 설정 할 수 있다.
		 	 Content-Disposition : form-data; name="memid" 	==> 파라미터명
		 	 			==> 빈줄
		 	 a001		==> 파라미터 값 
		 	 
		 	 2. 파일일 경우
		 	 	 -----문자문자자자ㅏ자아아아내용 			==> Part를 구분하는 구분선 ---- ,  웹브라우저 마다 다르게 설정 할 수 있다.
		 	 	  <!--구분선은 동일함 -->
		 	 
		 	 Content-Disposition : form-data; name="file1"; filename="파일명" 	==> 파일 정보 
		 	 Comtemt-Type : text/plain			==> 파일 종류 (파일 종류에 따라 값이 달라질 수 있다) 
		 	 			==> 빈줄
		 	 abcedfg12345		==> 파일 내용  
		 	 
		 */
		
		for(Part part : request.getParts()) {
			fileName = extractFileName(part);	// 파일명 구하기
			
			if(!"".equals(fileName)) {	//파일명이 공백이면 이것은 파일이 아닌 일반 파라미터라는 의미 
				
				//1개의 업로드 파일 정볼르 저장할 객체 생성 (파일일 때 처리)
				FileDetailVO detail = new FileDetailVO();
				
				detail.setFileName(fileName);	//파일 이름 저장
				detail.setFileSize((long)Math.ceil(part.getSize() / 1024.0));	//long으로 형변환을 해줘야한다
				try {
					part.write(uploadPath + File.separator + fileName);	//파일 저장하기 (파일 저장할 경로 설정)
					detail.setUploadStatus("Success");
				} catch (IOException e) {
					detail.setUploadStatus("Fail : " + e.getMessage());
				}
				fileList.add(detail);	//파일 정보를 저장한 객체 1개를 List에 추가 
			
			}//if문 종료 
		}//반복문 종료
		
		request.setAttribute("memId", memId);
		request.setAttribute("uploadFiles", fileList);
		
		RequestDispatcher rd = request.getRequestDispatcher("/05_file/uploadFiles.jsp");
		rd.forward(request, response);
		
		
	}//getPost()메서드 끝...
	
	
	
	//Part객체에서 파일 명을 찾는 메서드 ==> 파일이 아닌 Part일 경우에는 빈문자열("")을 반환한다.
	
	private String extractFileName(Part part) {
		String fileName = "";
		String contentDisposition = part.getHeader("Content-Disposition");
		String[] items = contentDisposition.split(";");
		for(String item : items) {
			if(item.trim().startsWith("filename")) {
				// ex. fileName ="test.txt"	==> 파일의 다음 2번째 글자("다음의 파일명)를 찾는다, 길이의 -1까지("전의 파일 이름 끝)  
				fileName = item.substring(item.indexOf("=")+2, item.length()-1);	
			}
		}
	
		return fileName;
	}

}
