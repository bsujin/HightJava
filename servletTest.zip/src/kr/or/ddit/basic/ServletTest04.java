package kr.or.ddit.basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletTest04
 */
@WebServlet(asyncSupported = true, description = "자동으로 생성한 서블릿", 
urlPatterns = { "/servletTest04" })
public class ServletTest04 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ServletTest04() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * Servlet클래스나 JSP 페이지의 환경에 관련된 정보는 javax.servlet.ServletContext 인터페이스 타입의 객체를 이용해서 얻을 수 있다 
		 * 
		 * - 제공하는 메서드
		 * 1. getServerInfo() ==> Servlet이 속하는 웹 서버의 종류
		 * 2. getMajorVersion() ==> 웹 컨테이너가 지원하는 Servlet 규격의 메이저 버전
		 * 3. getMinorVersion() ==> 마이너 버전
		 * 
		 */
		
		ServletContext context = getServletContext();	//ServletContect객체 얻기 
		
		String serverInfo = context.getServerInfo();
		int majorVersion = context.getMajorVersion();
		int minorVersion = context.getMinorVersion();
		
		String servletName = getServletName();
		
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head><meta Charset='utf-8'>");
		out.println("<title>웹 서버의 정보 </title></head>");
		out.println("<body>");
		out.println("웹 서버의 종류(ServerInfo) : " + serverInfo + "<br>");
		out.printf("Server Name : %s<br>", servletName);
		out.printf("지원하는 Servlet버전 : %d, %d<br><br>", majorVersion, minorVersion);
		 out.println("</body>");
		 out.println("</html>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		// -> 이런 글씨가 출력이 된다
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Post에서 get을 호출 : get방식이나 post방식을 구분하지 않고 사용하는 것 -> 공통적으로 사용한다 ( post를 사용해도
		// get을 호출하므로)
		doGet(request, response);
	}

}
