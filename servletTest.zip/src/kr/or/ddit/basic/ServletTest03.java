package kr.or.ddit.basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 	- 서블릿의 동작 방식에 대하여...
 	1. 사용자(클라이언트)가 URL을 클릭하면 HTTP Request를 Servlet Container로 전송(요청)한다.
 	
 	2. 컨테이너는 web.xml에 정의된 url패턴을 확인하여 어느 서블릿을 통해서 처리해야 할 지를 검색한다.
 		(로딩이 안된 경우에는 로딩을 한다 . 이 때 init() 메서드가 호출된다.)
 		(Servelet버전 3.0이상에서는 에노테이션(@WebServlet)으로 url패턴을 설정할 수 있다.)
 		
 	3. Servlet Container는 요청을 처리할 개별 쓰레드 객체를 생성하여 해당 서블릿 객체의 Service()메서드를 호출한다. ( => 첫번째로 service방식을 호출)
 	(이 때, HttpServletRequest객체와 HttpSerlvetResponse객체를 파라미터로 넘겨준다.) 
 	  => 자동으로 파라미터를 넘겨준다 
 	
 	4. service()메서드는 요청 메서드 타입을 체크하여 적절한 메서드를 호출한다.
 	 	(doGet(), doPost(), doPut(), doDelete() 등...)  (=> 실질적으로는 get, post를 처리한다)
 	 	
 	5. 요청 처리가 완료되면 HttpServletRequest객체와 HttpServletResponse객체는 자동으로 소멸된다.
 	
 	6. 컨테이너로부터 서블릿이 제거되는 경우에는 destroy()메서드가 호출된다.
 	
 	
 */

//5가지의 메서드를 다 사용하기  
@WebServlet("/servletTest03.do")
public class ServletTest03 extends HttpServlet{
	
	private static final long SerialVersionUID = 1L;
	

	@Override
	public void init() throws ServletException {
		System.out.println("Servlet : " + this.getServletName() + "에서 init()메서드를 호출합니다.");
	}
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Service() 메서드 시작...");
		
		//get방식과 post방식으로 자동으로 가려면 => get방식과 post방식에 맞는 메서드 호출학시
		
		//방법 1 : HttpServlet의 service()메서드로 위임하기 
		super.service(req, resp);	//super는 객체의 부모를 의미한다.
	
		
		//방법 2 : 클라이언트의 전송방식(Get, Post등 )을 구분해서 직접 메서드 호출 (간단한 작업은 코딩하지 않고 방법 1 을 사용하는 것이 효율적이다 )
		// service는 mvc패턴을 할 때 소스를 적합하게 작성하는것이 좋다 
		
//		String method = req.getMethod();
//		System.out.println("method ==> " + method);
//		if("GET".equals(method)) {
//			this.doGet(req, resp);
//		}else {
//			this.doPost(req, resp);
//		}
//		
		
		
		/*
		init 메서드가 끝나면 서비스로 자동 호출 -> 메서드 시작 호출됨 -> 
		서비스가 실행되면서 super를 만나위임을 하게 되면 방법2같은 작업을 처리해준다 -> get방식이므로 doget의 메서드가 시작된다 .
		 */
	}
	

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doGet() 메서드 시작 ...");
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		out.println("<html><head><meat charset-='utf-8'></head>"
				+ "<body><h1>doGet()메서드 처리 내용</h1></body></html>");
	
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doPost() 메서드 시작 ...");
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		out.println("<html><head><meat charset-='utf-8'></head>"
				+ "<body><h1>doPost()메서드 처리 내용</h1></body></html>");
	
	}
	
	@Override
	public void destroy() {
		System.out.println("SerVlet : " + this.getServletName() + "에서 destroy()메서드를 호출합니다.");
	}
	
	//html을 실행한 상태에서 test03의 소스를 수정하거나 변경하면 재부팅 된다 (destroy메서드가 실행된다)
	//중요한 것은 get방식과 post방식의 요청 차이점을 구분하는것 **
	
}


