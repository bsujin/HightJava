package kr.or.ddit.basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 	이 서블릿의 매핑 URL은 '/servletTest.do'로 하고
 	이 서블릿 초기화 파라미터로 'start'에는 1, 'end'에는 50을 설정한 후
 	이 초기화 파라미터값을 읽어와 start값 부터 end값 까지의 합계를 출력하는 서블릿을 작성하시오.
 */



@WebServlet("/ServletTest08.do")
public class ServletTest08 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		
		// 서블릿 초기화 파라미터값을 구하기
				// 방법1 : ServletConfig객체를 이용하기
//				ServletConfig config = getServletConfig(); //init
				
				// 형식 : getInParameter("파라미터 이름");
				// ==> 반환값을 무조건 String형으로 바뀐다.(파라미터 값이 숫자여도 문자로 다 읽혀진다)
//				String start = config.getInitParameter("start"); // config안에 지정한 글자와 똑같이 (대소문자 까지) 써줘야 한다
//				String end = config.getInitParameter("end");
				String start = getInitParameter("start"); // config안에 지정한 글자와 똑같이 (대소문자 까지) 써줘야 한다
				String end = getInitParameter("end");
				int s = Integer.parseInt(start);
				int e = Integer.parseInt(end);
				
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head><meta Charset='utf-8'>");
			out.println("<title>start-end값 구하기 </title></head>");
			out.println("<body>");
			out.println("<h2>"+start+"부터 " + end + "값을 구하기</h2>");
			out.println("start : " + start + "<br>");
			
			int sum=0;
			for(int i = s; i<=e; i++ ) {
				sum += i;
				
			}
			out.println("end : " + end + "<br>");
			out.println("합계 출력 : " + sum +"<br>");
			 out.println("</body>");
			 out.println("</html>");
			
	
	}
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

