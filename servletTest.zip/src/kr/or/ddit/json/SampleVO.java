package kr.or.ddit.json;

public class SampleVO {
	
	//멤버변수 2개 있는 vo생성
	private int num;
	private String name;
	
	public SampleVO(int num, String name) {
		super();
		this.num = num;
		this.name = name;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
