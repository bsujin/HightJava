package kr.or.ddit.okCommand;

// 수신자 역할의 클래스 

public class Heater {

	
	public void powerOn() {
		System.out.println("히터를 켰습니다.");
	}
	
	
}
