package kr.or.ddit.okCommand;

public class okCommand {
	
	private ICommand command;
	
	public void setCommand(ICommand command) {
		this.command = command;
	}
	
	public void run() {
		command.excute();
	}
}
