package kr.or.ddit.okCommand;

// 수신자의 기능을 수행하는 메서드를 갖는 인터페이스
public interface ICommand {
	public void excute();

	
}
