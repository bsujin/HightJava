package kr.or.ddit.okCommand;


// 수신자 역할의 클래스 ==> 실제 실행될 클래스

public class Lamp {
	
	// 램프를 키는 기능 
    public void turnOn() {
    	System.out.println("램프를 켰습니다.");
    }
    
    
}
