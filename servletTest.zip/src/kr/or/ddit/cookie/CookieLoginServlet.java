package kr.or.ddit.cookie;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookieLoginServlet.do")
public class CookieLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<html><head><meta charset='utf-8'>");
		out.println("<title>Loging</title><head>");
		out.println("<body>");

		// 값 가져오기 (userid, pass, chkid)
		String id = request.getParameter("userid");
		String pw = request.getParameter("pass");
		String chk = request.getParameter("chkid");

		
		// 비교할 문자열 저장
//		String dbId = "test";
//		String dbPw = "1234";

		// 쿠키 객체 생성
		Cookie cookie = new Cookie("saveid", id);

		// 체크박스의 체크여부에 따라서 쿠키를 저장하거나 삭제한다.
		if (chk != null) { // 체크되었을 때
			response.addCookie(cookie); // 쿠키저장
			cookie.setMaxAge(60 * 2);
		} else { // 체크가 되지 않으면
			cookie.setMaxAge(0); // 쿠키의 유효시간을 0으로 설저앟여 쿠키가 삭제되도록 한다
			response.addCookie(cookie);
		}

		String contextPath = request.getContextPath();

		// userid, pass의 null여부 체크 ==> 가져온 파라미터 값들의 null값 여부는 반드시 검사하는 것이 좋다.
		if (id != null & pw != null) {
//			if (dbId.equals(id) || dbPw.equals(pw)) {   변수로 비교해도 좋고, 직접 입력해도 상관없음 
				if ("test".equals(id) && "1234".equals(pw)) { //로그인 성공 
					//cookieMain.jsp로 이동 
				response.sendRedirect(request.getContextPath() + "/02_cookie/CookieMain.jsp");

			} else {
				//로그인에 실패 - cookieLogin.jsp 
				response.sendRedirect(request.getContextPath() + "/02_cookie/cookieLogin.jsp");
			}
		}

	
	
		out.println("</body>");
		out.println("</html>");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
