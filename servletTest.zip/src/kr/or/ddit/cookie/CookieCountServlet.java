package kr.or.ddit.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


// count 쿠키를 증가하는 클래스 

@WebServlet("/cookieCountServlet.do")
public class CookieCountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();

		// count라는 쿠키변수가 있는지 검사하기
		Cookie[] cookies = request.getCookies();
		int count = 0; // 0으로 초기화 한 이유는 저장이 안되있으면 0에서 증가하면 되므로

		if (cookies != null) {
			for (Cookie cookie : cookies) {
				String name = cookie.getName(); // 쿠키변수 구하기

				// count 라는 쿠키변수가 있으면 쿠키값( 현재 count값)을 구한다
				if ("count".equals(name)) {
					String value = cookie.getValue();
					count = Integer.parseInt(value); // 정수형으로 변환해준다.
				}
			}
		}
		
		count++;		//count 값 증가
		
		// 증가된 coutn값을 이용하여 새롭게 저장할 Cookie객체를 생성 (증가된 값을 저장 - 새로운 쿠키 객체 생성)
		Cookie countCookie = new Cookie("count", String.valueOf(count));	//쿠키는 문자열로 줘야한다 String.valueOf()를 사용하여 문자열로 바꿔줌
		
		//유지시간 주기
		countCookie.setMaxAge(24*60*60); 	// 1일    (60) 1분 , (60*60) 1시간   
		
		response.addCookie(countCookie);
		
		out.println("<html><head><meta charset='utf-8'>");
		out.println("<title>Cookie Count 연습</title><head>");
		out.println("<body>");
		out.println("<h2> 어서오세요. 당신은 " + count + "번 째 방문입니다.</h2><br><br>");
		out.println("<a href='" + request.getContextPath() + "/cookieCountServlet.do'>카운트 증가하기</a><br><br>");
		out.println("<a href='" + request.getContextPath() + "/02_cookie/cookieTest02.jsp'>시작문서로 이동하기</a>");
		
		out.println("</body>");
		out.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
