package kr.or.ddit.nonCommand;


// 호출자 역할의 클래스
public class NonCommand {
	
/*
	// 램프 켜기
	private Lamp lamp;  //램프의 참조값을 저장
	
	//생성자 만들기
	public NonCommand(Lamp lamp) {
		this.lamp = lamp;
	}
	
	//실행하는 메서드 
	public void run() {
		lamp.turnOn();
	}
	*/
	
	// 히터 켜기
	private Heater heater;	//히터가 저장될 변수 만들기
	
	// 생성자 만들기 
	public NonCommand(Heater heater) {
		this.heater = heater;
	}
	
	// 히터 켜기 기능 수행하기 
	public void run() {
		heater.powerOn();
	}
	
}
