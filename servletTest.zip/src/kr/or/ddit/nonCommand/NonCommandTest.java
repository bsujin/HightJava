package kr.or.ddit.nonCommand;


// 프로그램 실행 클래스 
public class NonCommandTest {

	public static void main(String[] args) {

		/*
		// 램프 켜기 기능 수행하기 
		Lamp lamp = new Lamp();
		NonCommand test = new NonCommand(lamp);	// 실행 할 클래스를 호출해 줄 객체를 실행할 때 호출하는 클래스의 멤버를 넣어 호출 
		test.run();
//		lamp.turnOn();  // 바로 직접  실행하는것 
	*/
		
		// 히터 켜기 기능 수행하기
		Heater heater = new Heater();
		NonCommand test = new NonCommand(heater);
		test.run();
	}

}
