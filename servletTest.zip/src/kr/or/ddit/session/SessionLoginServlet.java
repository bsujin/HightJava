package kr.or.ddit.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/sessionLoginServlet.do")
public class SessionLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get방식으로 요청하면 세션을 확인해서 세션이 없으면 로그인 폼(sessionLogin.jsp)으로 이동
		// 세션이 있으면 sessionResult.jsp로 이동

		// 세션 객체 생성
		HttpSession session = request.getSession();

		// 이동할 페이지 경로가 저장될 변수
		String viewPage = null;

		String userId = (String) session.getAttribute("USERID");
		if (userId == null) { // 세션이 없을 때
			viewPage = "/03_session/sessionLogin.jsp";
		} else { // 세션값이 있으면...
			viewPage = "/03_session/sessionResult.jsp";
		}

		// 페이지 이동하기 ==> forward방식이나 redirect방식 중 하나를 사용한다.

		// 방법1 ) redirect방식
		response.sendRedirect(request.getContextPath() + viewPage);

		// 방법2 ) forward방식
		// RequestDispatcher rd = request.getRequestDispatcher(viewPage);
		// rd.forward(request, response);

		/*
		 *===========================================
		 * 내가 한것  
		 * // 값 가져오기 (userid, pass, chkid) String id = request.getParameter("userid");
		 * String pw = request.getParameter("pass"); String chk =
		 * request.getParameter("chkid");
		 * 
		 * 
		 * //세션 객체 생성 HttpSession session = request.getSession();
		 * 
		 * // 체크박스의 체크여부에 따라서 쿠키를 저장하거나 삭제한다. // if (chk != null) { // 체크되었을 때 //
		 * session.setAttribute("id",id); // } else { // session.removeAttribute("id");
		 * // }
		 * 
		 * 
		 * response.setCharacterEncoding("utf-8");
		 * response.setContentType("text/html; charset=utf-8"); PrintWriter out =
		 * response.getWriter();
		 * 
		 * out.println("<html><head><meta charset='utf-8'>");
		 * out.println("<title>로그인창</title></head>"); out.println("<body>"); if (id !=
		 * null & pw != null) { if ("admin".equals(id) && "1234".equals(pw)) { //회원이면
		 * (로그인 성공) session.setAttribute("id",id);
		 * response.sendRedirect(request.getContextPath() +
		 * "/03_session/sessionResult.jsp");
		 * 
		 * } else { //로그인에 실패 - cookieLogin.jsp // session.setAttribute("id",id);
		 * response.sendRedirect(request.getContextPath() +
		 * "/03_session/sessionResult.jsp"); } }
		 * 
		 * out.println("</body>"); out.println("</html>");
		 */

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// doGet(request, response);
		// post방식으로 요청하면 로그인 검증 작업을 수행한다.
		request.setCharacterEncoding("utf-8");

		String userId = request.getParameter("userid");
		String pass = request.getParameter("pass");

		String viewPage = "/03_session/sessionResult.jsp";

		HttpSession session = request.getSession();

		if ((userId != null) && (pass != null)) {
			if("admin".equals(userId) && "1234".equals(pass)) {	//로그인 성공
				session.setAttribute("USERID", userId);
			}
		}
		response.sendRedirect(request.getContextPath() + viewPage);
	}

}
