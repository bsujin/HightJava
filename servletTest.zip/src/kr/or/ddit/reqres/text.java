package kr.or.ddit.reqres;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/text.do")
public class text extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; utf-8");

		String value1 = request.getParameter("value1");
		String value2 = request.getParameter("value2");
		String cal = request.getParameter("cal");
		// String sum = getInitParameter("sum");
		// String multy = getInitParameter("multy");
		// String div = getInitParameter("div");
		// String sub = getInitParameter("sub");
	
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><meta charset='utf-8'>" + "<title>계산 테스트</title></head>");
		out.println("<body>");
		out.println("<h2>text 테스트 결과 (숫자는 8자리까지 입력해주세요)</h2>");
		out.println("<hr>");
		out.println("첫번째 값 : " + value1);
		out.println("연산자 : " + cal);
		out.println("두번째 값 : " + value2);
		out.println("<hr>");

		int result = 0;

		switch (cal) {
		case "+":
			result = Integer.parseInt(value1) + Integer.parseInt(value2);
			break;
		case "-":
			result = Integer.parseInt(value1) - Integer.parseInt(value2);
			break;
		case "*":
			result = Integer.parseInt(value1) * Integer.parseInt(value2);
			break;
		case "/":
			result = Integer.parseInt(value1) / Integer.parseInt(value2);
			break;
		case "%":
			result = Integer.parseInt(value1) % Integer.parseInt(value2);
			break;


		}
		out.println("<h3> 결과 : " + value1 + cal + value2 + "  =  " + result + "<h3>");

		out.println("</table>");

		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
