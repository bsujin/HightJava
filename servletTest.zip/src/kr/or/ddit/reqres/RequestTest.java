package kr.or.ddit.reqres;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*
 *  server.xml 에서     get방식의 인코딩 방식 :  URIEncoding="utf-8"  
    post방식의 인코딩 방식 : request.setCharacterEncoding("utf-8");
    
 */

/*
 * form태그에서 만들어진 것을 action에 보내기 post방식, requestTest에서 doget에 했는데 작성이 됨  이유:  dopost에서  get을 호출함 => post방식에서는 post가 먼저 실행  
 * 처리하는 방식이 다르면 따로따로 처리해야한다 
 */

// HttpServletRequest객체 관련 예제 (JSP문서에서는 request객체)

@WebServlet("/RequestTest.do")
public class RequestTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
						//요청을 받을때, 요청을 보낼때 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		PrintWriter out = response.getWriter();

		// 요청할 때 넘어온 값을 가져오기(파라미터라 부른다)
		//form에서 선택한 데이터를 서블릿으로 넘어가는 것 -> 그러한 데이터를 파라미터로 지칭
		//reques.getParameter("파라미터명") ==> 해당 파라미터에 설정될 '값'을 가져온다.=> 가져온 값은 'String'형 이다.
		String userName = request.getParameter("username");
		String job = request.getParameter("job");
				
		//request.getParameterValues("파라미터명") 
		//	==> 전달되는 파라미터명이 여러개일 경우에 사용된다. (여러개일 경우 values를 사용) 
		// ==> 가져온 값은 'String[]'이다. (String 배열)

		//form에서 구성된 checkbox 중 선택된 값들을 모두 읽어온다. => 여러개이므로 배열에 담아준다 
		String[] hobbies = request.getParameterValues("hobby");
		
		out.println("<html>");
		out.println("<head><meta charset='utf-8'>"
				+ "<title>Request 객체연습</title></head>");
		out.println("<body>");
		out.println("<h2>request 테스트 결과</h2>");
		out.println("<hr>");
		
		out.println("<table border='1'>");
		out.println("<tr><td>이름</td>");
		out.println("<td>" + userName + "</td></tr>");
		
		out.println("<tr><td>직업</td>");
		out.println("<td>" + job + "</td></tr>");
		
		out.println("<tr><td>취미</td>");
		out.println("<td>");
		
		//배열의 크기만큼 반복
		for(int i=0; i<hobbies.length; i++) {
			out.println(hobbies[i] + "<br>");
		}
		out.println("</td></tr>");
		out.println("</table>");
		
		out.println("<hr>");
		out.println("<h2>request객체의 메서드들</h2>");
		out.println("<table border='1'> <tr><td>");
		out.println("1. 클라이언트의 IP주소 : " + request.getRemoteAddr() +"<br>");
		out.println("2. 요청 method : "+ request.getMethod() + "<br>");
		out.println("3. ContextPATH : " + request.getContextPath() + "<br>");
		out.println("4. 프로토콜 :  " + request.getProtocol() + "<br>");
		out.println("5. URL정보 : " + request.getRequestURL() + "<br>");
		out.println("6. URI정보 : " + request.getRequestURI() + "<br>");
					
		out.println("<br><hr><br>");
		
		//request.getParameterNames()  ==> 전송된 모든 파라미터의 이름을
		//	Enumeration<String> 객체에 담아서 반환한다.    ==> 파라미터의 이름만 반환하는것
		out.println("<h2>request.getParameterNames()메서드 처리결과</h2> ");
		out.println("<ul>");
		
		Enumeration<String>params = request.getParameterNames();
		//데이터가 여부를 검사하는 메서드 : hasMoreElements()
		//데이터를 가져오는 메서드 : nextElement()
		while(params.hasMoreElements()) {
			String name = params.nextElement();
			out.println("<li>" + name + "</li>");
		}
		out.println("</ul>");
						
		
		// request.getParameterMap() ==> 전송된 모든 파라미터를 Map객체에 담아서 반환한다.
		// 이 Map객체의 key값은 '파라미터명'이며 자료형은 'String'형이고,
		// value값은 파라미터에 저장된 '값'이며 자료형은 'String[]'이다. (String 배열)
		
		out.println("<h2>request.getParameterMap()메서드 처리 결과</h2>");
		out.println("<table border='1'> <tr><td> 파라미터 이름 </td>"
				+ "<td> 파라미터 value값</td></tr>");	
		 
		Map<String, String[]>paramMap = request.getParameterMap();
		for(String paramName : paramMap.keySet()) {
			out.println("<tr><td>" + paramName + "</td>");
			out.println("<td>");

			//파라미터 value값 가져오기 
			String[] paramValues = paramMap.get(paramName);
			
			if(paramValues==null || paramValues.length ==0) {	//파라미터가 없는 경우 - getParameter
				continue;
			}else if(paramValues.length==1) {					//파라미터가 배열이 아닌경우 - getParameterValues
				out.println(paramValues[0] + "<br>");
			}else {
				for(int i=0; i<paramValues.length; i++) {
					if(i>0) out.println(",");
					out.println(paramValues[i]);
				}
			}
			out.println("</td></tr>");
		}
		out.println("</table>");
		
		
		out.println("</body></html>");
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
