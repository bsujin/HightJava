package kr.or.ddit.reqres;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/text_sem.do")
public class text_sem extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; utf-8");
		PrintWriter out = response.getWriter();
		
		String value1 = request.getParameter("value1");
		String value2 = request.getParameter("value2");
		String cal = request.getParameter("cal");
		
		int num1 = Integer.parseInt(value1);
		int num2 = Integer.parseInt(value2);
		boolean calc = true;
		double result = 0; 	//계산된 결과가 저장될 면수 
	
		

		switch (cal) {
		case "+":
			result = num1 + num2;
			break;
			
		case "-":
			result = num1 - num2;
			break;
			
		case "*":
			result =  num1 * num2;
			break;
			
		case "/":
			if(num2==0) {
				calc = false; 
			}else {
				result = num1 / num2;
			}
			break;
			
		case "%":
			if(num2==0) {
				calc = false;
			}else {
			result = num1 % num2;
			}
			break;


		}
		
		out.println("<html>");
		out.println("<head><meta charset='utf-8'>" + "<title>계산 테스트</title></head>");
		out.println("<body>");
		out.println("<h2>text 테스트 결과 (숫자는 정수형으로 입력해주세요)</h2>");
		out.println("<hr>");
		

		out.println("<h3> 결과 : " + num1 + cal + num2 + "  =  " + result + "<h3>");
		if(calc==true) {
			out.println(result + "<br>");
		}else{
			out.println("계산 불능 (0으로 나누기) <br> ");
		}
//		out.printf("%d $s $d = %f<br>, num1, cal, num2, result");  //지정해서 출력 
		out.println("</table>");

		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
