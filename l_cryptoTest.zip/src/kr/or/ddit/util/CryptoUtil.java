package kr.or.ddit.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

//단방향으로 암호화를 처리하는 클래스 
public class CryptoUtil {

		//문자열을 MDS방식으로 암호화 한다. (자리수 : 32byte)
		public String md5(String msg) throws NoSuchAlgorithmException{
		
		//암호화를 지원 해주는 메서드 
		MessageDigest md = MessageDigest.getInstance("MD5");
		
		md.update(msg.getBytes()); 	//암호화하기
		
		return byteToHexString(md.digest());	//암호화한 데이터를 가져와 16진수로 변환해서 반환  (꺼내오는 명령어 : digest())
		
		// ==> 암호화한 데이터를 16진수로 많이 출력해주므로 변환해주고 변환해준 값을 반환한다.
		
	}
		
		// byte배열의 데이터를 16진수 값으로 변환하는 메서드 
		public String byteToHexString(byte[] data) {
			StringBuilder sb = new StringBuilder();
			for(byte b : data) {
				// &가 하나만 있으면 비트 and연산자   * 비트 : 0아니면 1밖에 없음 (0은 거짓, 1은 참)
				// 0x 는 16진수, ff / ((b & 0xff) + 0x100) ==> 16진수 2자리 만들기 
				// b가 10이라고 치면 16진수로 치면 10은 a,  
				// 0xa + 0x100 ==> 0x0a ==> 0xa + 0x100 ==> 0x10a ==> "10a"(문자열로 표시) ==> "0a" (문자열) 
				
				//    1010 & 11111111  ==> 00001010 + 100000000  => 100001010  ==> 10a  ==> "10a".substring(1) ==> "0a"
				sb.append(Integer.toHexString((b & 0xff) + 0x100).substring(1));	
				// toHexString : 16진수 문자열로 바꿔주는 메서드 
			}
			
			return sb.toString();	//데이터를 16진수 문자열로 바꿔준다 
			
		}
		
		//문자열을 SHA-256방식으로 암호화한다.(자리수 : 64byte)
		public String sha256(String msg) throws NoSuchAlgorithmException {
			MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
			sha256.update(msg.getBytes());
			return byteToHexString(sha256.digest());
		}
		
		//문자열을 SHA-512방식으로 암호화한다.(자리수 : 128byte)
		public String sha512(String msg) throws NoSuchAlgorithmException {
			MessageDigest sha512= MessageDigest.getInstance("SHA-512");
			sha512.update(msg.getBytes());
			return byteToHexString(sha512.digest());
		}

}
