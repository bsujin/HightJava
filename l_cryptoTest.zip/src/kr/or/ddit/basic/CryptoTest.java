package kr.or.ddit.basic;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.EncryptedPrivateKeyInfo;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import kr.or.ddit.util.AES256Utill;
import kr.or.ddit.util.CryptoUtil;

public class CryptoTest {

	public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
		CryptoUtil crypto = new CryptoUtil();
		
//		String plainText = "Hello, World";
		String plainText = "안녕하세요, 반갑습니다.";
		
		System.out.println("단방향 암호화");
		System.out.println("mds : " + crypto.md5(plainText));
		System.out.println("sha-256 : " + crypto.sha256(plainText));
		System.out.println("sha-512 : " + crypto.sha512(plainText));
		
		//사이트에서암호를 잃어버리면 임시 비밀번호를 주는것 -> 임시 비밀번호를 부여하여 다시 비밀번호를 바꾸는 것 ( 단방향으로 암호화)
		//처음에 썼던 암호가 암호화로 저장하였으므로 관리자도 비밀번호를 모르는 상태 -> 임의적으로 비밀번호(공개키) 를 주어 새로운 암호로 등록하는 것 
		System.out.println("\n=========================================\n");
		System.out.println("양방향 암호화 ");
		AES256Utill aes256 = new AES256Utill();
		String str = aes256.encrypt(plainText);	//암호화를 하는것 
		System.out.println("원래의 데이터 : " + plainText );
		System.out.println("암호화 문자열 길이 : " + str.length()+"byte");
		System.out.println("AES256암호화 : " + str);
		System.out.println("AES256복호화 : " + aes256.decrypt(str));	//복호화 해주는 메서드 
		
		System.out.println("\n=========================================\n");

		String tmp = " ";
		for(int i=0; i<=9; i++) {
			for(int j=0; j<=9; j++) {
				tmp += j;
				str = aes256.encrypt(tmp);
				System.out.println("tmp ==> " + tmp);
				System.out.println("암호화 ==> " + str);
				System.out.println("암호화 길이 ==> " + str.length());
				String deStr = aes256.decrypt(str);
				System.out.println("복호화 ==> " + deStr);
				System.out.println();
			}
		}
		
		
		
	}

}
