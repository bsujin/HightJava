package Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class BaseBall {

	public static void main(String[] args) {
		/*
		 * 문제 1: 5명의 사람 이름을 입력받아서 ArrayList에 저장한 후에 이들 중에서 '김'씨 성을 가진 사람의 이름을 모두 출력하시오
		 * (입력은 Scanner객체를 이용한다)
		 */

		// //1. ArrayList배열 만들고, 5명의 사람을 입력받기
		// Scanner sc = new Scanner(System.in);
		//
		// ArrayList<String> name = new ArrayList<>();
		//
		// for (int i = 0; i<name.size(); i++) {
		// System.out.print("이름을 입력하세요 >");
		// String input = sc.next();
		// name.add(input);
		//
		// }
		// for(int i = 0 : name ) {
		// if(name.get(i).get

		//
		Scanner scan = new Scanner(System.in);

		HashSet<Integer> random = new HashSet<>();
		while (random.size() < 3) {
			random.add((int) (Math.random() * 9) + 1);
		}

		List<Integer> game = new ArrayList<>(random);
		List<Integer> user = new ArrayList<>();
		System.out.println("game = " + game);
		int count = 0;
		int ball = 0;
		int strike = 0;

		while (strike != 3) {
			ball = 0;
			strike = 0;
			user.clear(); // clear를 해야 계속 값이 저장되지 않는다.
			count++;
//			while (user.size() < 3) {
//				System.out.println("숫자를 입력하세요 > ");
//				int input = scan.nextInt();
//				user.add(input);
//			}
//			System.out.println(user);
			HashSet<Integer> insert = new HashSet<>();
			while (insert.size() < 3) {
			System.out.println("숫자를 입력하세요 > ");
				
			
			insert.add(ScanUtill.nextInt());
			System.out.println("입력한 숫자는 :" + insert);
			}
			user = new ArrayList<>(insert);
		}


			for (int i = 0; i < game.size(); i++) {
				for (int j = 0; j < user.size(); j++) {
					if (game.get(i) == user.get(j)) {
						if (i == j) {
							strike++;
						} else {
							ball++;
						}
					}
				}

			}

			System.out.println(ball + "B " + strike + "S");

			// if(strike==3) break;

		}

		System.out.println(count);

	}

}
