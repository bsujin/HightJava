package hotel_vo;

public class hotelVO {

	private int room_no;
	private String name;
	private String roomtype;

	public String getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	public int getRoomNo() {
		return room_no;
	}
	public void setRoomNo(int room_no) {
		this.room_no = room_no;
	}
	public String getUserName() {
		return name;
	}
	public void setUserName(String name) {
		this.name = name;
	}
	
}
