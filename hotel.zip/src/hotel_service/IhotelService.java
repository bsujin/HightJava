package hotel_service;

import java.util.List;

import hotel_vo.hotelVO;

public interface IhotelService {
	/**
	 *  체크인(insert)
	 * @param hotelVo
	 * @return  작업성공 : 1, 작업실패 : 0
	 */
	public int chekIn(hotelVO hotelVo);

	/**
	 * 체크아웃(delete)
	 * @param hotelVo
	 * @return
	 */
	
//	public int chekOut(hotelVO hotelVo);

	public int chekOut(int roomNo);
	
	/**
	 * 객실 상태를 보는 메서드
	 * @return 객실 정보를 담고있는 hotelVo객체, 자료가 없으면 null
	 */
	public List<hotelVO>showRoom();
	
	
	/**
	 * 객실 번호를 매개값으로 받아서 해당 룸의 예약 상태를 반환하는 메서드 
	 * @param roomNo 검색할 객실번호 
	 * @return 			검색된 예약상태여부 
	 */
	public int stateRoom(int roomNo);
	
	/**
	 * 객실번호를 매개값으로 받아서 해당 객실 여부를 반환하는 메서드 
	 * 
	 * @param roomNo
	 * @return
	 */
	public int stateRoomNo(int roomNo);
}
