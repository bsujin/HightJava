package hotel_service;

import java.util.List;

import hotel_dao.hotelDao;
import hotel_vo.hotelVO;

public class hotelService implements IhotelService {

private hotelDao dao;
	
	private static hotelService service;
	
	private hotelService() {
		dao = hotelDao.getInstance();
	}
		
	public static hotelService getInstance() {
		if(service==null) service = new hotelService();
		return service;
	}

	@Override
	public int chekIn(hotelVO hotelVo) {
		return dao.chekIn(hotelVo);
	}

	@Override
	public int chekOut(int roomNo) {
		return dao.chekOut(roomNo);
	}

	@Override
	public List<hotelVO> showRoom() {
		return dao.showRoom();
	}

	@Override
	public int stateRoom(int roomNo) {
		return dao.stateRoom(roomNo);
	}

	@Override
	public int stateRoomNo(int roomNo) {
		// TODO Auto-generated method stub
		return dao.stateRoomNo(roomNo);
	}
	
	
}
