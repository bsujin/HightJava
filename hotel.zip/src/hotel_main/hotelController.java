package hotel_main;

import java.util.List;
import java.util.Scanner;

import hotel_service.IhotelService;
import hotel_service.hotelService;
import hotel_vo.hotelVO;

public class hotelController {

	private Scanner scan = new Scanner(System.in);
	private IhotelService service;

	public hotelController() {
		service = hotelService.getInstance();
	}

	public static void main(String[] args) {
		new hotelController().hotelStart();

	}

	private void hotelStart() {
		System.out.println();
		System.out.println("*********************************************");
		System.out.println("      호텔문을 열었습니다. 어서오십시요.");
		System.out.println("*********************************************");
		System.out.println();

		while (true) {
			int choice = displayMenu();
			switch (choice) {
			case 1: // 체크인
				checkIn();
				break;
			case 2: // 체크아웃
				checkOut();
				break;
			case 3: // 객실상태
				showRoom();
				break;
			case 4: // 업무종료
				System.out.println("*********************************************");
				System.out.println("       호 텔 문 을 닫 았 습 니 다.");
				System.out.println("*********************************************");
				return;
			default:
				System.out.println("작업번호를 잘못 입력했습니다. 다시 선택하세요.");
			}
		}

	}

	// 메뉴를 출력하고 작업번호를 입력받아 반환하는 메서드
	private int displayMenu() {
		System.out.println();

		System.out.println("-----------------------------------------------------------");
		System.out.println("어떤 업무를 하시겠습니까?");
		System.out.println("1. 체크인    2. 체크아웃    3. 객실상태    4. 업무종료");
		System.out.println("-----------------------------------------------------------");
		System.out.print(" 선택>> ");
		int num = Integer.parseInt(scan.nextLine());
		return num;
	}

	// 체크인을 처리하는 메서드
	private void checkIn() {

		int count = 0;

		System.out.println();
		System.out.println("------------------------------------");
		System.out.println("    체 크 인 작 업 ");
		System.out.println("------------------------------------");
		System.out.println(" * 201~209 : 싱글룸");
		System.out.println(" * 301~309 : 더블룸");
		System.out.println(" * 401~409 : 스위트룸");
		System.out.println("------------------------------------");

		System.out.print(" 방 번호 입력 >> ");
		int roomNo = Integer.parseInt(scan.nextLine());

		count = service.stateRoomNo(roomNo);

		if (count == 0) {
			System.out.println(roomNo + "호는 없는 방번호입니다");
			return;
		}

		count = service.stateRoom(roomNo);
		if (count > 0) {
			System.out.println(roomNo + "호는 이미 예약되었습니다.");
			return;
		}

		System.out.println("누구를 체크인 하시겠습니까?");
		System.out.print("이름 입력 >> ");
		String name = scan.nextLine();

		// 입력받은 예약 정보를 저장할 객체생성
		hotelVO hotelVo = new hotelVO();

		hotelVo.setRoomNo(roomNo);
		hotelVo.setUserName(name);

		int cnt = service.chekIn(hotelVo);
		if (cnt > 0) {
			System.out.println(name + "님 " + roomNo + "호 객실에 체크인 되었습니다.");
			System.out.println("\t감사합니다♬");
		} else {
			System.out.println("체크인 작업 실패~");
		}
	}

	// 체크아웃을 처리하는 메서드
	private void checkOut() {

		int count = 0;
		System.out.println();
		System.out.println("------------------------------------\n");
		System.out.println("    체 크 아 웃  작 업");
		System.out.println("------------------------------------\n");
		System.out.println("체크 아웃할 방 번호와 예약자 이름을 입력하세요.");

		System.out.print(" 방 번호 입력  >> ");
		int roomNo = Integer.parseInt(scan.nextLine());

		count = service.stateRoomNo(roomNo);

		if (count == 0) {
			System.out.println(roomNo + "호는 없는 방번호입니다");
			return;
		}

		// 해당 객실에 손님이 없는지 검사
		count = service.stateRoom(roomNo);
		if (count == 0) {
			System.out.println(roomNo + "호 객실에는 체크아웃할 손님이 없습니다.");
			return;
		}
//		 System.out.print("예약자 이름 입력 >>");
//		 String name = scan.nextLine();
//		// if(hotelVo.getUserName().equals(name)) {
//
//		hotelVO hotelVo = new hotelVO();
//		hotelVo.setRoomNo(roomNo);
//		hotelVo.setUserName(name);
//		count = service.chekOut(hotelVo);
		count = service.chekOut(roomNo);
		
		if (count > 0) {
//			System.out.println(roomNo + "호 " +name + "님 체크아웃을 완료했습니다.");
			System.out.println(roomNo + "호 체크아웃을 완료했습니다.");
			System.out.println("다음에 또 이용해주세요~");
		} else {
			System.out.println("체크아웃 작업 이 취소되었습니다.");
			return;
		}
	}
	
	// 객실 상태를 출력하는 메서드
	private void showRoom() { 
	System.out.println();
	
	 List<hotelVO> reList = null;
	 reList = service.showRoom();
	if(reList==null || reList.size()==0) {
	System.out.println(" 예약이 하나도 없습니다.");
	}
	
	 System.out.println(); 
	 System.out.println("======================================");
	 System.out.println("        현 재 객 실 상 태");
	 System.out.println("-----------------------------------");
	 System.out.println("    방번호\t 방종류\t 투숙객 이름");
	 System.out.println("-----------------------------------");
	 
	  // List에서 방번호를 하나씩 꺼내와 Map에서 해당 방번호에 해당하는 Room객체를 구해서 출력한다. 
	 for(hotelVO hotelVo : reList) {
			System.out.println("  " +hotelVo.getRoomNo() + "호\t"
							+ hotelVo.getRoomtype()  +"\t"
							+ hotelVo.getUserName());
		}
	 System.out.println("======================================");
	 
	}
}