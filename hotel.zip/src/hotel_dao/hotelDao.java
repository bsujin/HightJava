package hotel_dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import hotel_vo.hotelVO;

public class hotelDao implements IhotelDao {

	private SqlMapClient smc;
	private Reader rd;

	// 인터페이스에서 만들어진 메서드를 자동으로 만들어줌
	// 직접적으로 db에 데이터를 작업하는 메서드 -> 입력하는것은 컨트롤러, 실제 db작업만 사용
	private static final Logger logger = Logger.getLogger(hotelDao.class);

	// 1. 자신 Class의 참조값이 저장될 변수를 private static으로 선언한다.
	private static hotelDao dao;

	// 2. 생성자의 접근 제한자를 private으로 한다.
	private hotelDao() {
		try {
			// 1-1. 문자 인코등 캐릭터 셋 설정
			Charset charset = Charset.forName("UTF-8");
			Resources.setCharset(charset);

			// 1-2 환경 설정 파일을 읽어온다.
			rd = Resources.getResourceAsReader("sqlMapConfig.xml");

			// 1-3. 위에서 읽어온 Reader객체를 이용하여 실제 환경설정을 완성한 후
			// SQL문을 호출해서 실행할 수 있는 객체를 생성한다.
			smc = SqlMapClientBuilder.buildSqlMapClient(rd);

			rd.close();

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (rd != null)	try {	rd.close(); 	} catch (IOException e) {}

		}
	}

	// 3. 자신 class의 인스턴스를 생성하고, 생성된 인스턴스의 참조값을 반환하는 메서드를 public static으로 작성한다.
	// ( 이 메서드의 이름은 보통 getInstance()로 한다. )
	public static hotelDao getInstance() {
		if (dao == null)
			dao = new hotelDao();
		return dao;
	}

	// 체크인 하는 메서드
	@Override
	public int chekIn(hotelVO hotelVo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("hotel.checkIn", hotelVo);
			if (obj == null)
				cnt = 1; // 성공하면 null이므로 1로 반환되어 결과 성공값으로 바뀐다.

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// 체크아웃하는 메서드
	// public int chekOut(hotelVO hotelVo) { //이름까지 해보기
	// cnt = smc.delete("hotel.checkOut", hotelVo);

	@Override
	public int chekOut(int roomNo) {
		int cnt = 0;
		try {
			cnt = smc.delete("hotel.checkOut", roomNo);

		} catch (Exception e) {
			cnt = 0;
			e.printStackTrace();
		}
		return cnt;
	}

	//객실상태를 출력하는 메서드 
	@Override
	public List<hotelVO> showRoom() {
		List<hotelVO> relist = null;
		try {
			
			relist = smc.queryForList("hotel.showRoom");
			
		} catch (Exception e) {
			relist = null;
			e.printStackTrace();
		}
		
		return relist;
	}

	//예약 확인 
	@Override
	public int stateRoom(int roomNo) {
		int cnt = 0;

		try {

			cnt = (int) smc.queryForObject("hotel.getRoom", roomNo);

		} catch (Exception e) {
			cnt = 0;
			e.printStackTrace();
		}
		return cnt;
	}

	//객실 확인 
	@Override
	public int stateRoomNo(int roomNo) {
		int cnt = 0;

		try {

			cnt = (int) smc.queryForObject("hotel.getRoomNo", roomNo);

		} catch (Exception e) {
			cnt = 0;
			e.printStackTrace();
		}
		return cnt;
	}

}
