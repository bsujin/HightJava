package kr.or.ddit.basic;

public class DocTest {

	public static void main(String[] args) {
	
		JavaDocTestInf test = null;
		
		test.methodAdd(1, 2);
	}

}
